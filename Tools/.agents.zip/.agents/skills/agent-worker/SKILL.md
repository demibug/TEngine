---
name: agent-worker
description: 将单个有界代码任务委派给外部 coding agent，支持 Explore、Investigate、Implement、InvestigateAndImplement 和 Review。用于成本明显的源码调查、局部实现、验证或独立审查，也是 task-slice 的执行层；多任务切片和技术决策留给 Codex。
---

# Agent Worker

## 原则

每次调用只处理一个有界任务。调用者给出目标、范围、验收条件；写任务另传精确 `WriteSet`。保持 `Backend=Auto`、`Profile=Auto`，由 runtime 处理最高权限 backend 调用、路由、fallback、timeout、变更报告和结果发布。尽量让 worker 在一次运行内完成充分调查、自验和压缩结论，Codex 不重建其调查。

## Kind

- `Explore`：只读建立事实和候选边界，不生成最终任务图。
- `Investigate`：只读调查明确问题的根因、影响和证据。
- `Implement`：按已有决策在 `WriteSet` 内实现并自验。
- `InvestigateAndImplement`：在既定目标和 `WriteSet` 内调查、实现并自验；有技术选择时修改前停止。
- `Review`：只读独立审查，明确通过、问题或不确定原因。

## 契约

- 至少提供 `Goal`、`Scope`、`ExpectedOutput`、`AcceptanceCriteria`；按需补充 `KnownContext`、`DependsOn`、`RiskHints`。
- 写任务传入工程相对、无通配符的精确文件路径；只读 Kind 不传 `WriteSet`。`WriteSet` 是预期范围和快照基线，不是权限边界；范围外变化允许但会报告，不自动阻止或回滚。
- 公共 API、数据语义、生命周期、持久化、序列化、共享状态、跨模块契约、多方案取舍、扩大 `WriteSet` 或用户行为选择属于 Decision Boundary：修改前停止，压缩说明证据、选项和未修改状态。
- 一次调查应尽量覆盖目标；证据仍不足时可继续发起聚焦的 `Explore` 或 `Investigate`。在 `KnownContext` 传入已确认事实、剩余未知项和前次 `RunId`，不得用重复调查回避决策。

## 调用与结果

在目标 workspace 根目录、PowerShell 7 shell 中运行用户级技能脚本；runtime 直接以当前目录作为源码、`WriteSet`、验证和输出的基准：

```powershell
& "$HOME\.agents\skills\agent-worker\scripts\delegate.ps1" `
  -Kind InvestigateAndImplement -Task $task `
  -WriteSet @('Assets/Scripts/Foo/FooManager.cs') -TimeoutSeconds 600
```

只读任务省略 `WriteSet`；审查既有运行可传 `-ReviewOfRunId <RunId>`。默认不提权运行 delegate。C 盘写入不得直接拒绝：调用者先展示精确 workspace、相对且无通配符的 WriteSet 和操作类型，再由主 Codex 申请外层权限；仅在用户批准后执行本次授权，删除需单独审批。

- 跟踪同一 shell session 至明确 `exit_code`：`Completed` 返回 0，`NeedsDecision` 返回 2，其余返回 1。
- 成功只读 `result.txt`；仅基础设施诊断读取 `error.txt` 或 raw。验收 `ExpectedWriteSet`、`ActualChangedFiles` 和 `OutOfWriteSetChanges`。
- fallback 仅处理基础设施失败且写集未变化；语义问题、验证失败、Review issue、写集不足或 Decision Boundary 返回 Codex。
- worker 完成自验并报告风险。低风险直接验收；中风险安排独立 Worker Review；高风险再由 Codex Review。验证失败、大 diff 或审查冲突升级 Codex Review。
