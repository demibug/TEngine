---
name: agent-worker
description: 将单个有界代码任务委派给外部 coding agent，支持 Scout、Explore、Investigate、Implement、InvestigateAndImplement 和 Review；多任务切片和技术决策留给 Codex。
---

# Agent Worker

## 原则

Codex 先判断能否直接完成，不默认委派；仅缺少决定任务边界所必需的工程事实时调用 Scout。每次调用只处理一个有界任务。保持 `Backend=Auto`、`Profile=Auto`，由 runtime 处理 backend 调用、fallback、timeout、变更报告和结果发布。

复杂度同时按 `Decision Risk` 和 `Execution Breadth` 判断，不以文件数量为主。前者包括 API、生命周期、共享状态、数据语义和架构选择；后者包括搜索范围、调用链、文件范围、验证步骤、独立目标、依赖和波次。高 `Decision Risk` 必须返回 Codex 决策。

## Kind

Scout 是受限 `Explore`。

- `Explore`：只读建立事实和候选边界，不生成任务图。
- `Investigate`：只读调查根因、影响和证据。
- `Implement`：按已有决策在 `WriteSet` 内实现并自验。
- `InvestigateAndImplement`：在既定目标和 `WriteSet` 内调查、实现并自验。
- `Review`：只读独立验收，明确通过、问题或不确定原因。

## 契约与路由

- 必填：`Goal`、`Scope`、`ExpectedOutput`、`AcceptanceCriteria`；按需传 `KnownContext`、`DependsOn`、`RiskHints`、`ContractSet`。`KnownContext` 传已确认事实、剩余未知项和前次 `RunId`，不得重复调查。
- 写任务传工程相对、无通配符的精确 `WriteSet`；`ContractSet` 标记依赖或修改的接口、事件、数据契约和共享语义。只读 Kind 不传 `WriteSet`。`WriteSet` 是快照基线，不是权限边界；范围外变化允许但须报告，不自动阻止或回滚。
- Scout 只读返回 `RelevantFiles`、`CallChain`、`RiskFlags`、`SuggestedScope`、`SuggestedWriteSet`、`SuggestedRouting`、`Evidence`；不改代码、不做架构决策或完整方案，足够即停，不扫描无关大范围源码。Codex 只传探路所需目标、约束和问题，不转发完整用户上下文。
- 根因和边界明确：`Implement`；根因未知且不会产生重要技术决策：`InvestigateAndImplement`；可能影响 API、生命周期、共享状态、数据语义、架构或实现方案：`Investigate` 后由 Codex 决策再 `Implement`；只做事实探索：`Explore`；独立验收：`Review`。`InvestigateAndImplement` 非默认。
- Decision Boundary：公共 API/契约、生命周期、持久化、序列化、共享状态、数据语义、多方案取舍、扩大 `WriteSet`/`ContractSet`、非预期用户可感知行为、与已有修改冲突、无法可靠验证。修改前停止并返回 `NeedsDecision`，说明证据、选项和未修改状态。
- Sol Gate：进入 Decision Boundary 或高风险 Codex Review 时，若主会话不是 `gpt-5.6-sol`，停止并明确输出 `SolRequired`，请用户在当前任务的模型选择器切换到 Sol 后继续；不得自动启动原生 subagent，也不得越过边界修改。当前已是 Sol 时直接按原有决策与验收规则继续，不提示切换，也不改默认模型配置。

## 调用与结果

在 workspace 根目录、PowerShell 7 运行用户级脚本；当前目录是源码、`WriteSet`、验证和输出基准。外层 Codex `exec_command` 必须申请 `sandbox_permissions=require_escalated`，以 `justification` 说明 workspace、WriteSet 和操作类型；sandbox 提升不属于 `delegate.ps1` 参数。

```powershell
& "$HOME\.agents\skills\agent-worker\scripts\delegate.ps1" `
  -Kind $kind -Task $task `
  -WriteSet $writeSet -TimeoutSeconds $timeoutSeconds
```

### 单次工具内等待（必须）

通过一次 `functions.exec` 加载并调用固定的 `scripts/wait-session.js`；只传 `delegateCommand`、workspace 和外层授权参数，不读取脚本正文到模型上下文，也不重写等待循环：

```javascript
const source = await tools.exec_command({cmd: 'Get-Content -Raw "$env:USERPROFILE/.agents/skills/agent-worker/scripts/wait-session.js"'});
if (source.exit_code) throw new Error(source.output);
await (0, eval)(source.output)({cmd: delegateCommand, workdir: workspace});
```

`functions.exec` 的等待上限设为 worker timeout 加 60 秒；若宿主仍返回运行中的 cell，只用 `functions.wait` 等待。不得在主模型层调用 `write_stdin` 或注入 raw 日志。

### 外部停止

固定等待脚本会直接通知运行中的 `RunId`。用户可在外部 PowerShell 执行以下命令；它只发送本地事件，不调用 Codex 模型：

```powershell
& "$HOME\.agents\skills\agent-worker\scripts\stop-worker.ps1" `
  -Workspace $workspace -RunId $runId
```

取消会终止对应 Worker 进程树并返回退出码 1、`WorkerOutcome: Cancelled`；不得自动回滚，仍须验收停止前的文件变化。

只读任务省略 `WriteSet`；审查既有运行可传 `-ReviewOfRunId <RunId>`。每次 delegate 均须外层 sandbox 外授权；未获批准不得降级或绕过。C 盘写入不得直接拒绝：按上述 `WriteSet` 规则展示 workspace 和操作类型后申请权限；仅用户批准后执行，删除单独审批。

`OpenCodeHomeMode = 'User'` 继承当前用户的 Provider、认证、插件和状态；未设置则 `Isolated`，XDG 目录会保留在 `.agent-worker-output/runs/<RunId>/opencode-xdg`，便于诊断。`User` 仅用于依赖用户级配置的 Profile，且依赖上述外层授权。

- 跟踪同一 shell session 至明确 `exit_code`：`Completed` 返回 0，`NeedsDecision` 返回 2，`Cancelled` 和其余终态返回 1。
- 正常结果仅保留 Codex 决策和验收所需信息；原始日志留磁盘，默认不进 Codex 上下文。成功只读 `result.txt`；仅基础设施诊断读取错误摘要或必要 raw 片段。验收 `ExpectedWriteSet`、`ActualChangedFiles`、`OutOfWriteSetChanges`。
- fallback 仅处理基础设施失败且写集未变化；语义问题、验证失败、Review issue、写集不足或 Decision Boundary 返回 Codex。
- Codex 负责需求理解、路由、技术决策、共享契约和 task-slice 确认、worker 验收、最终 diff/验证/回复。agent-worker 只执行有界 Explore/Investigate/Implement/Verify/Review。低风险 Codex 验收；中风险可独立 Worker Review；高风险 Codex Review。
