@{
    Profiles = @{
        opencodeClaudeGLM = @{
            Backend = 'OpenCode'
            Model = 'igg/claude-glm-5.2'
            OpenCodeHomeMode = 'User'
            AllowProjectSource = $true
        }
        opencodeDeepseek = @{
            Backend = 'OpenCode'
            Model = 'opencode-go/deepseek-v4-flash'
            AllowProjectSource = $true
        }
        opencodeAmdDeepseek = @{
            Backend = 'OpenCode'
            Model = 'amd/DeepSeek-V4-Flash'
            OpenCodeHomeMode = 'User'
            AllowProjectSource = $true
        }
        commandcodeDeepseek = @{
            Backend = 'CommandCode'
            Model = 'deepseek/deepseek-v4-flash'
            AllowProjectSource = $true
        }
    }

    Routes = @('commandcodeDeepseek', 'opencodeClaudeGLM', 'opencodeAmdDeepseek', 'opencodeDeepseek')
}
