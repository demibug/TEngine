@{
    Profiles = @{
        OpenCodeDeepSeek = @{
            Backend = 'OpenCode'
            Model = 'opencode-go/deepseek-v4-flash'
            AllowProjectSource = $true
        }
        CommandCodeDeepSeek = @{
            Backend = 'CommandCode'
            Model = 'deepseek/deepseek-v4-flash'
            AllowProjectSource = $true
        }
        ClaudeCodeGLM = @{
            Backend = 'ClaudeCode'
            Model = 'claude-glm-5.2'
            Effort = 'high'
            AllowProjectSource = $true
        }
    }

    Routes = @('OpenCodeDeepSeek', 'ClaudeCodeGLM', 'CommandCodeDeepSeek')
}
