Set-StrictMode -Version Latest

function Get-ClaudeCodeCommand {
    [CmdletBinding()]
    param()

    $commands = @(Get-Command 'claude' -All -ErrorAction SilentlyContinue)
    $command = $commands | Where-Object { $_.Source -match '(?i)\.exe$' } | Select-Object -First 1
    if ($null -eq $command) {
        $command = $commands | Where-Object { $_.Source -match '(?i)\.(cmd|bat)$' } | Select-Object -First 1
    }
    if ($null -eq $command) {
        $command = $commands | Where-Object { $_.Source -match '(?i)\.ps1$' } | Select-Object -First 1
    }
    if ($null -eq $command) {
        return $null
    }

    $source = if ([string]::IsNullOrWhiteSpace($command.Source)) {
        $command.Definition
    }
    else {
        $command.Source
    }
    if ([string]::IsNullOrWhiteSpace($source) -or -not (Test-Path -LiteralPath $source -PathType Leaf)) {
        return $null
    }

    if ($source -match '(?i)\.ps1$') {
        return [PSCustomObject]@{
            FilePath = Join-Path $PSHOME 'pwsh.exe'
            PrefixArguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', $source)
        }
    }
    if ($source -match '(?i)\.(cmd|bat)$') {
        return [PSCustomObject]@{
            FilePath = Join-Path $PSHOME 'pwsh.exe'
            PrefixArguments = @(
                '-NoLogo', '-NoProfile', '-NonInteractive',
                '-Command', '& $args[0] @($args[1..($args.Count - 1)]); exit $LASTEXITCODE',
                $source
            )
        }
    }

    return [PSCustomObject]@{
        FilePath = $source
        PrefixArguments = @()
    }
}

function New-ClaudeCodeArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Model,
        [AllowEmptyString()][string]$Effort = ''
    )

    $arguments = @(
        '-p'
        '--model', $Model
        '--output-format', 'stream-json'
        '--verbose'
        '--no-session-persistence'
        '--dangerously-skip-permissions'
        # Worker 不需要用户 hook、插件等启动定制，避免它们写入 C 盘运行时目录。
        '--safe-mode'
        # 继续加载用户级 cc-switch endpoint、认证和模型映射。
        '--setting-sources', 'user'
    )
    if (-not [string]::IsNullOrWhiteSpace($Effort)) {
        $arguments += @('--effort', $Effort)
    }
    return $arguments
}

function New-ClaudeCodeInvocation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][hashtable]$Profile,
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Task
    )

    $command = Get-ClaudeCodeCommand
    if ($null -eq $command) {
        return $null
    }

    return [PSCustomObject]@{
        FilePath = $command.FilePath
        ArgumentList = @($command.PrefixArguments) + @(
            New-ClaudeCodeArguments `
                -Kind $Kind `
                -Model ([string]$Profile.Model) `
                -Effort ([string]$Profile.Effort)
        )
        Environment = @{}
        RawKind = 'Ndjson'
        # prompt 走 stdin：claude -p 不带位置参数时读取 stdin 作为提示词。
        InputText = $Task
    }
}

function ConvertFrom-ClaudeCodeOutput {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Content)

    $trimmed = $Content.Trim()
    if ([string]::IsNullOrWhiteSpace($trimmed)) {
        throw 'Claude Code 输出为空。'
    }

    $frame = $null
    foreach ($line in @($trimmed -split '\r?\n')) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try {
            $candidate = $line | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "Claude Code 输出包含非法 NDJSON：$($_.Exception.Message)"
        }
        if ([string]$candidate.type -eq 'result') { $frame = $candidate }
    }

    if ($null -eq $frame) { throw 'Claude Code 输出缺少最终 result frame。' }

    if ([string]$frame.subtype -ne 'success') {
        throw "Claude Code 结果不是 success：$([string]$frame.subtype)"
    }
    $isError = $null -ne $frame.PSObject.Properties['is_error'] -and $frame.is_error -eq $true
    $apiErrorStatus = if ($null -ne $frame.PSObject.Properties['api_error_status']) {
        $frame.api_error_status
    }
    else { $null }
    if ($isError -or $null -ne $apiErrorStatus) {
        throw "Claude Code 返回 API 错误：$([string]$apiErrorStatus)"
    }
    $permissionDenials = @()
    if ($null -ne $frame.PSObject.Properties['permission_denials']) {
        $permissionDenials = @($frame.permission_denials)
    }
    if ($permissionDenials.Count -gt 0) {
        throw 'Claude Code 结果包含权限拒绝。'
    }
    if ([string]::IsNullOrWhiteSpace([string]$frame.result)) {
        throw 'Claude Code 最终结果为空。'
    }
    return [string]$frame.result
}

function Get-ClaudeCodeFailureInfo {
    [CmdletBinding()]
    param(
        [int]$ExitCode,
        [AllowEmptyString()][string]$StdErr = '',
        [AllowEmptyString()][string]$StdOut = ''
    )

    $combined = "$StdErr`n$StdOut"
    $category = 'AgentTool'
    $canFallback = $false
    if ($combined -match '(?i)authentication_failed|authentication failed|invalid api key|oauth.*not.*allowed|401') {
        $category = 'Auth'; $canFallback = $true
    }
    elseif ($combined -match '(?i)rate_limit|rate limit|429|overloaded') {
        $category = 'RateLimit'; $canFallback = $true
    }
    elseif ($combined -match '(?i)unrecognized_model|model_not_found|model not found|unknown model|not available') {
        # cc-switch 可能先发布模型映射警告；仅在 CLI 非零退出时参与 fallback。
        $category = 'Provider'; $canFallback = $true
    }
    elseif ($combined -match '(?i)billing_error|billing error|insufficient.*credit|credit.*balance') {
        $category = 'Credits'; $canFallback = $true
    }
    elseif ($combined -match '(?i)server_error|server error|500|502|503|504') {
        $category = 'Server'; $canFallback = $true
    }
    elseif ($combined -match '(?i)connection refused|ecONNREFUSED|enotfound|enetunreach|network error|fetch failed') {
        $category = 'Network'; $canFallback = $true
    }
    elseif ($combined -match '(?i)invalid_request|bad request|400') {
        $category = 'Config'
    }

    return [PSCustomObject]@{ Category = $category; CanFallback = $canFallback; ExitCode = $ExitCode }
}

Export-ModuleMember -Function @(
    'Get-ClaudeCodeCommand',
    'New-ClaudeCodeArguments',
    'New-ClaudeCodeInvocation',
    'ConvertFrom-ClaudeCodeOutput',
    'Get-ClaudeCodeFailureInfo'
)
