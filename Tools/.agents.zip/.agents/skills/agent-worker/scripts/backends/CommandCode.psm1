Set-StrictMode -Version Latest

function Get-CommandCodeCommand {
    [CmdletBinding()]
    param()

    foreach ($name in @('command-code', 'cmdc')) {
        $commands = @(Get-Command $name -All -ErrorAction SilentlyContinue)
        $command = $commands | Where-Object { $_.Source -match '(?i)\.exe$' } | Select-Object -First 1
        if ($null -eq $command) {
            $command = $commands | Where-Object { $_.Source -match '(?i)\.ps1$' } | Select-Object -First 1
        }
        if ($null -eq $command) {
            $command = $commands | Where-Object { $_.Source -match '(?i)\.(cmd|bat)$' } | Select-Object -First 1
        }
        if ($null -eq $command) { continue }

        $source = if ([string]::IsNullOrWhiteSpace($command.Source)) { $command.Definition } else { $command.Source }
        if ([string]::IsNullOrWhiteSpace($source) -or -not (Test-Path -LiteralPath $source -PathType Leaf)) {
            continue
        }
        if ($source -match '(?i)\.ps1$') {
            return [PSCustomObject]@{
                FilePath = Join-Path $PSHOME 'pwsh.exe'
                PrefixArguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', $source)
            }
        }
        if ($source -match '(?i)\.(cmd|bat)$') {
            return [PSCustomObject]@{
                FilePath = Join-Path $PSHOME 'pwsh.exe'
                PrefixArguments = @(
                    '-NoLogo', '-NoProfile', '-NonInteractive',
                    '-Command', '& $args[0] @($args[1..($args.Count - 1)]); exit $LASTEXITCODE',
                    $source
                )
            }
        }
        return [PSCustomObject]@{ FilePath = $source; PrefixArguments = @() }
    }
    return $null
}

function New-CommandCodeArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Task,
        [AllowEmptyString()][string]$Model = ''
    )

    $arguments = @(
        '-p', $Task
        '--trust'
        '--skip-onboarding'
        '--no-session'
        '--output-format', 'json'
        '--max-turns', '30'
        '--yolo'
        '--tools-all'
    )
    if (-not [string]::IsNullOrWhiteSpace($Model)) {
        $arguments += @('--model', $Model)
    }
    return $arguments
}

function New-CommandCodeInvocation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][hashtable]$Profile,
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Task
    )

    $command = Get-CommandCodeCommand
    if ($null -eq $command) {
        return $null
    }
    return [PSCustomObject]@{
        FilePath = $command.FilePath
        ArgumentList = @($command.PrefixArguments) + @(
            New-CommandCodeArguments -Kind $Kind -Task $Task -Model ([string]$Profile.Model)
        )
        Environment = @{}
        RawKind = 'Ndjson'
    }
}

function ConvertFrom-CommandCodeOutput {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Content)

    $result = $null
    foreach ($line in @($Content -split '\r?\n')) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try {
            $frame = $line | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "Command Code 输出包含非法 NDJSON：$($_.Exception.Message)"
        }
        if ($frame.type -eq 'result') { $result = $frame }
    }
    if ($null -eq $result) { throw 'Command Code 输出缺少最终 result frame。' }
    if ($result.subtype -ne 'success') { throw "Command Code 结果不是 success：$($result.subtype)" }
    if ([string]::IsNullOrWhiteSpace([string]$result.finalText)) { throw 'Command Code 最终结果为空。' }
    return [string]$result.finalText
}

function Get-CommandCodeFailureInfo {
    [CmdletBinding()]
    param(
        [int]$ExitCode,
        [AllowEmptyString()][string]$StdErr = '',
        [AllowEmptyString()][string]$StdOut = ''
    )

    $category = switch ($ExitCode) {
        3 { 'Auth' }; 5 { 'RateLimit' }; 6 { 'Network' }; 7 { 'Server' }; 10 { 'Credits' }
        4 { 'PermissionDenied' }; 8 { 'MaxTurns' }; 9 { 'NoResponse' }; default { 'AgentTool' }
    }
    $canFallback = $ExitCode -in @(3, 5, 6, 7, 10)
    if (-not $canFallback -and "$StdErr`n$StdOut" -match '(?i)provider.*unavailable|model.*unavailable') {
        $category = 'Provider'; $canFallback = $true
    }
    return [PSCustomObject]@{ Category = $category; CanFallback = $canFallback; ExitCode = $ExitCode }
}

Export-ModuleMember -Function @(
    'Get-CommandCodeCommand',
    'New-CommandCodeArguments',
    'New-CommandCodeInvocation',
    'ConvertFrom-CommandCodeOutput',
    'Get-CommandCodeFailureInfo'
)
