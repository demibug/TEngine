Set-StrictMode -Version Latest

function Get-OpenCodePermissionJson {
    [CmdletBinding()]
    param()

    return [ordered]@{
        task = 'allow'
        external_directory = 'allow'
        edit = 'allow'
        bash = 'allow'
    } | ConvertTo-Json -Compress
}

function Get-OpenCodeCommand {
    [CmdletBinding()]
    param()

    $commands = @(Get-Command opencode -All -ErrorAction SilentlyContinue)
    $command = $commands | Where-Object { $_.Source -match '(?i)\.exe$' } | Select-Object -First 1
    if ($null -eq $command) {
        $command = $commands | Where-Object { $_.Source -match '(?i)\.ps1$' } | Select-Object -First 1
    }
    if ($null -eq $command) {
        $command = $commands | Where-Object { $_.Source -match '(?i)\.(cmd|bat)$' } | Select-Object -First 1
    }
    if ($null -eq $command) {
        return $null
    }

    $source = if ([string]::IsNullOrWhiteSpace($command.Source)) { $command.Definition } else { $command.Source }
    if ([string]::IsNullOrWhiteSpace($source) -or -not (Test-Path -LiteralPath $source -PathType Leaf)) {
        return $null
    }
    if ($source -match '(?i)\.ps1$') {
        return [PSCustomObject]@{
            FilePath = Join-Path $PSHOME 'pwsh.exe'
            PrefixArguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', $source)
        }
    }
    if ($source -match '(?i)\.(cmd|bat)$') {
        return [PSCustomObject]@{
            FilePath = Join-Path $PSHOME 'pwsh.exe'
            PrefixArguments = @(
                '-NoLogo', '-NoProfile', '-NonInteractive',
                '-Command', '& $args[0] @($args[1..($args.Count - 1)]); exit $LASTEXITCODE',
                $source
            )
        }
    }
    return [PSCustomObject]@{ FilePath = $source; PrefixArguments = @() }
}

function New-OpenCodeInvocation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][hashtable]$Profile,
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Task,
        [Parameter(Mandatory = $true)][string]$ProjectDir,
        [Parameter(Mandatory = $true)][string]$RunDir
    )

    $command = Get-OpenCodeCommand
    if ($null -eq $command) {
        return $null
    }
    $xdgRoot = Join-Path $RunDir 'opencode-xdg'
    $environment = @{
        OPENCODE_PERMISSION = Get-OpenCodePermissionJson
        # OpenCode 的可写配置、日志、数据库和缓存都留在 Run 内，避免触碰 C 盘。
        XDG_CONFIG_HOME = Join-Path $xdgRoot 'config'
        XDG_DATA_HOME = Join-Path $xdgRoot 'data'
        XDG_CACHE_HOME = Join-Path $xdgRoot 'cache'
        XDG_STATE_HOME = Join-Path $xdgRoot 'state'
        XDG_RUNTIME_DIR = Join-Path $xdgRoot 'runtime'
    }
    $authContent = $env:OPENCODE_AUTH_CONTENT
    if ([string]::IsNullOrWhiteSpace($authContent)) {
        $authFile = Join-Path $HOME '.local\share\opencode\auth.json'
        try {
            if (Test-Path -LiteralPath $authFile -PathType Leaf) {
                # 仅在内存中转发认证，不复制到 Run，也不输出凭证内容。
                $authContent = Get-Content -LiteralPath $authFile -Raw -Encoding UTF8
            }
        }
        catch {
            # 未开放 C 盘读取时让 CLI 返回可诊断的认证失败，不复制或提升权限。
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($authContent)) {
        try { [void]($authContent | ConvertFrom-Json -ErrorAction Stop) }
        catch { throw 'OpenCode auth.json 不是合法 JSON。' }
        $environment.OPENCODE_AUTH_CONTENT = $authContent
    }

    $arguments = @($command.PrefixArguments) + @(
        'run'
        '--dir', $ProjectDir
        '--model', [string]$Profile.Model
        '--format', 'default'
        '--auto'
    )
    $arguments += $Task

    return [PSCustomObject]@{
        FilePath = $command.FilePath
        ArgumentList = $arguments
        Environment = $environment
        CleanupDirectories = @($xdgRoot)
        RawKind = 'Text'
    }
}

function Get-OpenCodeFailureInfo {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$StdErr = '',
        [AllowEmptyString()][string]$StdOut = '',
        [int]$ExitCode = 1
    )

    $details = "$StdErr`n$StdOut"
    $category = 'AgentTool'
    $canFallback = $false
    if ($details -match '(?i)EEXIST|bootstrap|config(?:uration)?\s+(?:failed|error)') {
        $category = 'Config'; $canFallback = $true
    }
    elseif ($details -match '(?i)unauthorized|forbidden|authentication|login\s+(?:failed|required)|invalid\s+(?:token|credential)') {
        $category = 'Auth'; $canFallback = $true
    }
    elseif ($details -match '(?i)rate\s*limit|status\s*429') {
        $category = 'RateLimit'; $canFallback = $true
    }
    elseif ($details -match '(?i)credit|quota|billing') {
        $category = 'Credits'; $canFallback = $true
    }
    elseif ($details -match '(?i)network|connection|ECONN|ENOTFOUND|timeout') {
        $category = 'Network'; $canFallback = $true
    }
    elseif ($details -match '(?i)provider|model.*(?:unavailable|not found|invalid)|status\s*5\d\d|server error') {
        $category = 'Provider'; $canFallback = $true
    }
    elseif ($details -match '(?i)permission\s+denied|denied by permission') {
        $category = 'PermissionDenied'
    }
    return [PSCustomObject]@{ Category = $category; CanFallback = $canFallback; ExitCode = $ExitCode }
}

Export-ModuleMember -Function @(
    'Get-OpenCodePermissionJson',
    'Get-OpenCodeCommand',
    'New-OpenCodeInvocation',
    'Get-OpenCodeFailureInfo'
)
