[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Explore', 'Investigate', 'Implement', 'InvestigateAndImplement', 'Review')]
    [string]$Kind,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Task,

    [string[]]$WriteSet = @(),

    [ValidateSet('Auto', 'OpenCode', 'CommandCode', 'ClaudeCode')]
    [string]$Backend = 'Auto',

    [string]$Profile = 'Auto',

    [string]$ReviewOfRunId = '',

    [ValidateRange(30, 3600)]
    [int]$TimeoutSeconds = 600,

    # 仅用于确定性自测；生产调用必须保持 None。
    [Parameter(DontShow = $true)]
    [ValidateSet('None', 'Success', 'NonZeroExit', 'Timeout', 'PermissionBlockStdOut', 'PermissionBlockStdErr', 'IgnoredModelWarning', 'NeedsDecision', 'Failed', 'EmptyResult', 'OutOfWriteSet')]
    [string]$TestMode = 'None'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8NoBom
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

$skillDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$runtimeModule = Join-Path $PSScriptRoot 'lib\WorkerRuntime.psm1'
$openCodeModule = Join-Path $PSScriptRoot 'backends\OpenCode.psm1'
$commandCodeModule = Join-Path $PSScriptRoot 'backends\CommandCode.psm1'
$claudeCodeModule = Join-Path $PSScriptRoot 'backends\ClaudeCode.psm1'
$configFile = Join-Path $skillDir 'config\workers.psd1'

Import-Module $runtimeModule -Force
Import-Module $openCodeModule -Force
Import-Module $commandCodeModule -Force
Import-Module $claudeCodeModule -Force

$run = $null
$workerExitCode = $null
$failureStage = 'Initialization'
$lastStdOut = ''
$lastStdErr = ''
$rawTextSections = [System.Collections.Generic.List[string]]::new()
$rawNdjsonSections = [System.Collections.Generic.List[string]]::new()

function Add-RawAttempt {
    param(
        [Parameter(Mandatory = $true)][string]$RawKind,
        [Parameter(Mandatory = $true)][string]$ProfileName,
        [AllowEmptyString()][string]$StdOut = '',
        [AllowEmptyString()][string]$StdErr = ''
    )

    if ($RawKind -eq 'Ndjson') {
        if (-not [string]::IsNullOrWhiteSpace($StdOut)) {
            # 保持 raw.ndjson 为可逐行解析的原始事件流，不混入说明文本。
            $rawNdjsonSections.Add($StdOut.TrimEnd())
        }
        if (-not [string]::IsNullOrWhiteSpace($StdErr)) {
            $rawTextSections.Add(@(
                "===== Profile: $ProfileName / STDERR ====="
                $StdErr
            ) -join [Environment]::NewLine)
        }
    }
    else {
        $rawTextSections.Add(@(
            "===== Profile: $ProfileName ====="
            'STDOUT:'
            $StdOut
            ''
            'STDERR:'
            $StdErr
        ) -join [Environment]::NewLine)
    }
}

function Publish-RawAttempts {
    if ($null -eq $run) { return }
    if ($rawTextSections.Count -gt 0 -and -not (Test-Path -LiteralPath $run.RawTextFile)) {
        Write-WorkerText `
            -Path $run.RawTextFile `
            -Content ($rawTextSections -join ([Environment]::NewLine + [Environment]::NewLine))
    }
    if ($rawNdjsonSections.Count -gt 0 -and -not (Test-Path -LiteralPath $run.RawNdjsonFile)) {
        Write-WorkerText -Path $run.RawNdjsonFile -Content ($rawNdjsonSections -join [Environment]::NewLine)
    }
}

function Remove-InvocationTemporaryDirectories {
    param([Parameter(Mandatory = $true)][psobject]$Invocation)

    if ($null -eq $run -or $null -eq $Invocation.PSObject.Properties['CleanupDirectories']) { return }
    $runPrefix = [System.IO.Path]::TrimEndingDirectorySeparator(
        [System.IO.Path]::GetFullPath($run.RunDir)
    ) + [System.IO.Path]::DirectorySeparatorChar
    foreach ($path in @($Invocation.CleanupDirectories)) {
        $fullPath = [System.IO.Path]::GetFullPath([string]$path)
        if (-not $fullPath.StartsWith($runPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "临时目录越出 Run：$fullPath"
        }
        if (Test-Path -LiteralPath $fullPath -PathType Container) {
            $info = Get-Item -LiteralPath $fullPath -Force
            if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "拒绝删除临时重解析点：$fullPath"
            }
            [System.IO.Directory]::Delete($fullPath, $true)
        }
    }
}

function New-TestInvocation {
    param(
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$OutsidePath
    )

    $childCommand = @'
$ErrorActionPreference = 'Stop'
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

switch ($env:AGENT_WORKER_TEST_MODE) {
    'Success' {
        if ($env:AGENT_WORKER_TEST_KIND -eq 'Review') {
            [Console]::Out.WriteLine("审查完成，未发现问题，可以通过。`nWorkerOutcome: Completed")
        }
        else {
            [Console]::Out.WriteLine("任务已完成。确定性证据与自测均通过。`nWorkerOutcome: Completed")
        }
        exit 0
    }
    'NeedsDecision' {
        [Console]::Out.WriteLine("需要 Codex 决策后才能继续；尚未修改文件。`nWorkerOutcome: NeedsDecision")
        exit 0
    }
    'Failed' {
        [Console]::Out.WriteLine("验证未通过，任务未完成。`nWorkerOutcome: Failed")
        exit 0
    }
    'OutOfWriteSet' {
        [System.IO.File]::WriteAllText($env:AGENT_WORKER_TEST_OUTSIDE_PATH, 'outside', $utf8NoBom)
        [Console]::Out.WriteLine("任务已完成，同时修改了预期范围外文件。`nWorkerOutcome: Completed")
        exit 0
    }
    'EmptyResult' { exit 0 }
    'NonZeroExit' {
        [Console]::Error.WriteLine('AGENT_WORKER_TEST_NON_ZERO_EXIT')
        exit 23
    }
    'Timeout' {
        $grandChildCommand = 'Start-Sleep -Seconds 120'
        $grandChildEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($grandChildCommand))
        $grandChild = Start-Process `
            -FilePath $env:AGENT_WORKER_TEST_PWSH `
            -ArgumentList @('-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', $grandChildEncoded) `
            -WindowStyle Hidden `
            -PassThru
        [Console]::Out.WriteLine("TEST_CHILD_PID:$($grandChild.Id)")
        [Console]::Out.Flush()
        Start-Sleep -Seconds 120
        exit 0
    }
    'PermissionBlockStdOut' {
        $grandChildCommand = 'Start-Sleep -Seconds 120'
        $grandChildEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($grandChildCommand))
        $grandChild = Start-Process `
            -FilePath $env:AGENT_WORKER_TEST_PWSH `
            -ArgumentList @('-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', $grandChildEncoded) `
            -WindowStyle Hidden `
            -PassThru
        [Console]::Out.WriteLine("TEST_PERMISSION_STDOUT_CHILD_PID:$($grandChild.Id)")
        [Console]::Out.Flush()
        [Console]::Out.WriteLine("EACCES: permission denied, open 'D:\blocked.txt'")
        [Console]::Out.Flush()
        Start-Sleep -Seconds 120
        exit 0
    }
    'PermissionBlockStdErr' {
        $grandChildCommand = 'Start-Sleep -Seconds 120'
        $grandChildEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($grandChildCommand))
        $grandChild = Start-Process `
            -FilePath $env:AGENT_WORKER_TEST_PWSH `
            -ArgumentList @('-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', $grandChildEncoded) `
            -WindowStyle Hidden `
            -PassThru
        [Console]::Out.WriteLine("TEST_PERMISSION_STDERR_CHILD_PID:$($grandChild.Id)")
        [Console]::Out.Flush()
        [Console]::Error.WriteLine("UnauthorizedAccessException: Access to the path 'C:\blocked.txt' is denied.")
        [Console]::Error.Flush()
        Start-Sleep -Seconds 120
        exit 0
    }
    'IgnoredModelWarning' {
        [Console]::Error.WriteLine('[claude-code:unrecognized_model] model mapping warning')
        [Console]::Error.Flush()
        Start-Sleep -Seconds 2
        [Console]::Out.WriteLine("模型告警后仍正常完成。`nWorkerOutcome: Completed")
        exit 0
    }
}
'@

    $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($childCommand))
    $invocation = [PSCustomObject]@{
        FilePath = Join-Path $PSHOME 'pwsh.exe'
        ArgumentList = @('-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', $encodedCommand)
        Environment = @{
            AGENT_WORKER_TEST_MODE = $Mode
            AGENT_WORKER_TEST_KIND = $Kind
            AGENT_WORKER_TEST_PWSH = Join-Path $PSHOME 'pwsh.exe'
            AGENT_WORKER_TEST_OUTSIDE_PATH = $OutsidePath
        }
        RawKind = 'Text'
    }
    return $invocation
}

try {
    $projectDir = Resolve-WorkerProjectRoot
    if ([string]::IsNullOrWhiteSpace($Task)) { throw 'Agent Worker 任务不能为空。' }

    $normalizedWriteSet = @($WriteSet | ForEach-Object {
        ConvertTo-WorkerRelativePath -ProjectDir $projectDir -Path $_
    } | Select-Object -Unique)
    $isWriteKind = $Kind -in @('Implement', 'InvestigateAndImplement')
    if ($isWriteKind -and $normalizedWriteSet.Count -eq 0) {
        throw "$Kind 必须提供至少一个精确 WriteSet 文件路径。"
    }
    if (-not $isWriteKind -and $normalizedWriteSet.Count -gt 0) {
        throw "$Kind 是只读任务，不接受 WriteSet。"
    }

    $config = Import-PowerShellDataFile -LiteralPath $configFile
    $profiles = $config.Profiles
    $routes = $config.Routes
    $previousBackend = ''
    $previousRunKind = ''
    $reviewTargetContext = ''
    if (-not [string]::IsNullOrWhiteSpace($ReviewOfRunId)) {
        if ($Kind -ne 'Review') { throw 'ReviewOfRunId 只能用于 Review。' }
        if ($ReviewOfRunId -cnotmatch '^[0-9a-f]{32}$') { throw 'ReviewOfRunId 格式无效。' }

        $newResultFile = Join-Path $projectDir ".agent-worker-output\runs\$ReviewOfRunId\result.txt"
        $legacyResultFile = Join-Path $projectDir ".codex\agent-worker-output\$ReviewOfRunId\result.txt"
        $previousResultFile = if (Test-Path -LiteralPath $newResultFile -PathType Leaf) {
            $newResultFile
        }
        elseif (Test-Path -LiteralPath $legacyResultFile -PathType Leaf) {
            $legacyResultFile
        }
        else {
            throw "找不到 ReviewOfRunId 对应结果：$ReviewOfRunId"
        }

        $previousResult = Get-Content -LiteralPath $previousResultFile -Raw -Encoding UTF8
        $backendPattern = if ($TestMode -eq 'None') {
            '(?im)^Backend:\s*(OpenCode|CommandCode|ClaudeCode)\s*$'
        }
        else {
            '(?im)^Backend:\s*(OpenCode|CommandCode|ClaudeCode|Test)\s*$'
        }
        $backendMatches = [regex]::Matches($previousResult, $backendPattern)
        $kindMatches = [regex]::Matches(
            $previousResult,
            '(?im)^Kind:\s*(Explore|Investigate|Implement|InvestigateAndImplement|Review)\s*$'
        )
        if ($backendMatches.Count -ne 1 -or $kindMatches.Count -ne 1) {
            throw 'ReviewOfRunId 对应结果缺少唯一可信的 Backend 或 Kind 元数据。'
        }
        $previousBackend = $backendMatches[0].Groups[1].Value
        $previousRunKind = $kindMatches[0].Groups[1].Value
        [void](Test-WorkerOutcome -Content $previousResult)
        # 不向 reviewer 转发前一 worker 的自由文本，避免其内容成为新的指令来源。
        $reviewTargetContext = @"
# Review 目标
- RunId: $ReviewOfRunId
- PreviousKind: $previousRunKind
- 独立检查当前源码与调用者指定的范围，不采信或复述前一 worker 的结论。
"@
    }

    if ($TestMode -ne 'None') {
        $candidateNames = @('__Test__')
    }
    elseif ($Profile -ne 'Auto') {
        if (-not $profiles.ContainsKey($Profile)) { throw "未知 Worker Profile：$Profile" }
        $candidateNames = @($Profile)
    }
    else {
        $candidateNames = @($routes)
    }
    if ($TestMode -eq 'None' -and -not [string]::IsNullOrWhiteSpace($previousBackend)) {
        $candidateNames = @($candidateNames | Sort-Object {
            if ([string]$profiles[$_].Backend -ne $previousBackend) { 0 } else { 1 }
        })
    }
    if ($TestMode -eq 'None' -and $Backend -ne 'Auto') {
        $candidateNames = @($candidateNames | Where-Object {
            [string]$profiles[$_].Backend -eq $Backend
        })
    }
    if ($candidateNames.Count -eq 0) { throw '没有满足 Backend/Profile 条件的 Worker Profile。' }

    $requestedProfile = if ($TestMode -ne 'None') { 'Test' } else { [string]$candidateNames[0] }
    $requestedBackend = if ($TestMode -ne 'None') {
        'Test'
    }
    else {
        [string]$profiles[$requestedProfile].Backend
    }

    [void](Invoke-WorkerCleanup -ProjectDir $projectDir)
    $run = New-WorkerRun `
        -ProjectDir $projectDir `
        -Kind $Kind `
        -RequestedBackend $requestedBackend `
        -RequestedProfile $requestedProfile

    [Console]::Out.WriteLine("RunId: $($run.RunId)")
    [Console]::Out.WriteLine("RunDir: $($run.RunDir)")
    [Console]::Out.WriteLine("ResultFile: $($run.ResultFile)")
    [Console]::Out.WriteLine("ErrorFile: $($run.ErrorFile)")
    [Console]::Out.Flush()

    $writeSetText = if ($normalizedWriteSet.Count -eq 0) {
        '<none>'
    }
    else {
        ($normalizedWriteSet | ForEach-Object { "- $_" }) -join [Environment]::NewLine
    }
    $kindContract = switch ($Kind) {
        'Explore' { '只读建立事实和候选边界；不得修改文件。' }
        'Investigate' { '只读调查明确问题的根因、影响和证据；不得修改文件。' }
        'Implement' { '使用已有决策实现并完成 self-validation。' }
        'InvestigateAndImplement' { '在既定目标内调查、实现并 self-validation；出现真实技术选择时在修改前停止。' }
        'Review' { '保持只读；明确说明可以通过、发现的问题或无法确定的原因。' }
    }
    $baseContract = @"
# Agent Worker 固定契约
- 本工程为 Unity SLG 客户端；遵守根 AGENTS.md，由实际执行修改的 agent 按要求触发并读取匹配的项目 Skill/reference。
- 自行搜索 Scope 所需源码；默认优先 Assets/、Packages/、ProjectSettings/，无明确需要时不扫描 Library/、Temp/、Logs/、obj/。
- Git/SVN 只读，不访问远端；禁止覆盖用户已有修改或启动其他 worker/subagent。
- 禁止读取、发送或输出 API key、token、password、private key、cookie、credentials、真实隐私、敏感生产数据和任务无关 .env；发现时跳过或替换为 <REDACTED>，任务依赖时返回 NeedsDecision。
- backend 以最高权限模式运行，但仍受最外层 Codex sandbox 约束；不要尝试绕过外层权限或请求审批。
- 本次 Kind：$Kind。
- 本次 ExpectedWriteSet：
$writeSetText
- WriteSet 是调用者预期范围和变更报告基线，不是 backend 权限边界；确有必要时允许修改范围外文件，但必须在正文明确说明原因，禁止修改无关文件，不得自动回滚。
- Kind 契约：$kindContract
- Decision Boundary 包括公共 API、数据语义、生命周期、序列化、持久化、共享状态归属、跨模块 contract、多个合理实现及 trade-off、明显扩大预期范围或用户行为选择。出现这些选择时停止且不修改。
- 输出末尾必须单独包含且只能包含一个机器终态：WorkerOutcome: Completed、WorkerOutcome: NeedsDecision 或 WorkerOutcome: Failed。
- 只有任务与必要验证全部完成才可使用 Completed；需要 Codex 决策且尚未修改时使用 NeedsDecision；权限拒绝、验证失败、任务未完成或其他失败使用 Failed。
- 先归纳再输出：不复述任务，不汇报搜索过程，不罗列无关文件，不粘贴长代码或日志，只保留结论、关键证据、实际变更、验证、风险和下一步。
- 正文通常不超过 1500 字符，复杂 Explore 最多 2500 字符；RunId、Kind、Backend、Profile 和变更清单由脚本追加，不要自行输出。
"@
    $fullTask = $baseContract + [Environment]::NewLine + [Environment]::NewLine + $Task
    if (-not [string]::IsNullOrWhiteSpace($reviewTargetContext)) {
        $fullTask += [Environment]::NewLine + [Environment]::NewLine + $reviewTargetContext
    }
    if ($fullTask.Length -gt 30000) { throw "Agent Worker 任务过长（$($fullTask.Length) chars）。" }

    $attemptErrors = [System.Collections.Generic.List[string]]::new()
    $failedBackends = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    $hasTerminalResult = $false
    $finalExitCode = 1

    foreach ($profileName in $candidateNames) {
        $beforeSnapshot = Get-WorkerWorkspaceSnapshot -ProjectDir $projectDir
        if ($TestMode -ne 'None') {
            $resolvedBackend = 'Test'
            $resolvedProfile = 'Test'
            $outsidePath = Join-Path $projectDir ".agent-worker-selftest-outside-$($run.RunId).txt"
            $invocation = New-TestInvocation -Mode $TestMode -OutsidePath $outsidePath
        }
        else {
            $profileConfig = $profiles[$profileName]
            if ($profileConfig.AllowProjectSource -ne $true) {
                throw "Profile 未授权接收普通工程源码：$profileName"
            }
            $resolvedBackend = [string]$profileConfig.Backend
            $resolvedProfile = $profileName
            if ($failedBackends.Contains($resolvedBackend)) { continue }

            $invocation = if ($resolvedBackend -eq 'OpenCode') {
                New-OpenCodeInvocation `
                    -Profile $profileConfig `
                    -Kind $Kind `
                    -Task $fullTask `
                    -ProjectDir $projectDir `
                    -RunDir $run.RunDir
            }
            elseif ($resolvedBackend -eq 'CommandCode') {
                New-CommandCodeInvocation -Profile $profileConfig -Kind $Kind -Task $fullTask
            }
            elseif ($resolvedBackend -eq 'ClaudeCode') {
                New-ClaudeCodeInvocation -Profile $profileConfig -Kind $Kind -Task $fullTask
            }
            else {
                throw "Profile 使用未知 Backend：$resolvedBackend"
            }

            if ($null -eq $invocation) {
                [void]$failedBackends.Add($resolvedBackend)
                $attemptErrors.Add("$profileName/${resolvedBackend}: CLI 不存在")
                continue
            }
        }

        $failureStage = "Worker:$resolvedBackend"
        $effectiveTimeout = if ($TestMode -eq 'Timeout') { 1 } else { $TimeoutSeconds }
        $inputText = if ($null -ne $invocation.PSObject.Properties['InputText']) {
            [string]$invocation.InputText
        }
        else { '' }
        try {
            $processResult = Start-WorkerProcess `
                -FilePath $invocation.FilePath `
                -ArgumentList @($invocation.ArgumentList) `
                -WorkingDirectory $projectDir `
                -Environment $invocation.Environment `
                -InputText $inputText `
                -TimeoutSeconds $effectiveTimeout
        }
        finally {
            Remove-InvocationTemporaryDirectories -Invocation $invocation
        }

        $workerExitCode = $processResult.ExitCode
        $lastStdOut = $processResult.StdOut
        $lastStdErr = $processResult.StdErr
        Add-RawAttempt `
            -RawKind $invocation.RawKind `
            -ProfileName $resolvedProfile `
            -StdOut $lastStdOut `
            -StdErr $lastStdErr

        if ($processResult.PermissionBlocked) {
            throw "$resolvedProfile/$resolvedBackend 遇到读写权限 BLOCK，已立即终止：$($processResult.BlockText)"
        }

        $afterSnapshot = Get-WorkerWorkspaceSnapshot -ProjectDir $projectDir
        $changeRecords = @(Compare-WorkerWorkspaceSnapshot -Before $beforeSnapshot -After $afterSnapshot)
        $actualChangedFiles = @($changeRecords | ForEach-Object { [string]$_.Path })
        $workspaceUnchanged = $actualChangedFiles.Count -eq 0

        if ($processResult.TimedOut) {
            if ($TestMode -eq 'None' -and $workspaceUnchanged) {
                $attemptErrors.Add("$resolvedProfile/${resolvedBackend}: Timeout")
                continue
            }
            throw "Worker 超时（${effectiveTimeout}s），已终止进程树。"
        }

        if ($workerExitCode -ne 0) {
            if ($TestMode -ne 'None') {
                $failureInfo = [PSCustomObject]@{ Category = $TestMode; CanFallback = $false }
            }
            elseif ($resolvedBackend -eq 'OpenCode') {
                $failureInfo = Get-OpenCodeFailureInfo -StdErr $lastStdErr -StdOut $lastStdOut -ExitCode $workerExitCode
            }
            elseif ($resolvedBackend -eq 'ClaudeCode') {
                $failureInfo = Get-ClaudeCodeFailureInfo -ExitCode $workerExitCode -StdErr $lastStdErr -StdOut $lastStdOut
            }
            else {
                $failureInfo = Get-CommandCodeFailureInfo -ExitCode $workerExitCode -StdErr $lastStdErr -StdOut $lastStdOut
            }

            if ($failureInfo.CanFallback -and $workspaceUnchanged) {
                $attemptErrors.Add("$resolvedProfile/${resolvedBackend}: $($failureInfo.Category)")
                if (Test-WorkerBackendWideFailure -Category $failureInfo.Category) {
                    [void]$failedBackends.Add($resolvedBackend)
                }
                continue
            }
            if (-not $workspaceUnchanged) {
                throw "$resolvedProfile 基础设施失败后工程文件已变化，拒绝自动 fallback。"
            }
            throw "$resolvedProfile/$resolvedBackend 调用失败：$($failureInfo.Category)，exit code $workerExitCode"
        }

        if ([string]::IsNullOrWhiteSpace($lastStdOut)) {
            throw "$resolvedProfile/$resolvedBackend 正常退出，但 stdout 为空。"
        }
        $workerText = if ($resolvedBackend -eq 'CommandCode') {
            ConvertFrom-CommandCodeOutput -Content $lastStdOut
        }
        elseif ($resolvedBackend -eq 'ClaudeCode') {
            ConvertFrom-ClaudeCodeOutput -Content $lastStdOut
        }
        else {
            $lastStdOut
        }

        $outcomeResult = Test-WorkerOutcome -Content $workerText
        if (-not $isWriteKind -and $actualChangedFiles.Count -gt 0) {
            throw "$Kind 是只读任务，但 worker 修改了工程文件。"
        }
        if ($outcomeResult.Outcome -eq 'NeedsDecision' -and $actualChangedFiles.Count -gt 0) {
            throw 'Worker 返回 NeedsDecision，但工程文件已发生修改。'
        }

        $expectedSet = [System.Collections.Generic.HashSet[string]]::new(
            [System.StringComparer]::OrdinalIgnoreCase
        )
        foreach ($path in $normalizedWriteSet) { [void]$expectedSet.Add($path) }
        $outOfWriteSetChanges = @($actualChangedFiles | Where-Object { -not $expectedSet.Contains($_) })
        $publishedResult = Add-WorkerMetadata `
            -Content $outcomeResult.Content `
            -RunId $run.RunId `
            -Kind $Kind `
            -Backend $resolvedBackend `
            -Profile $resolvedProfile `
            -Outcome $outcomeResult.Outcome `
            -ExpectedWriteSet $normalizedWriteSet `
            -ActualChangedFiles $actualChangedFiles `
            -OutOfWriteSetChanges $outOfWriteSetChanges

        Publish-RawAttempts
        Write-WorkerResult -Run $run -Content $publishedResult
        [Console]::Out.WriteLine("Backend: $resolvedBackend")
        [Console]::Out.WriteLine("Profile: $resolvedProfile")
        [Console]::Out.WriteLine("WorkerOutcome: $($outcomeResult.Outcome)")
        [Console]::Out.Flush()
        $finalExitCode = switch ($outcomeResult.Outcome) {
            'Completed' { 0 }
            'NeedsDecision' { 2 }
            'Failed' { 1 }
        }
        $hasTerminalResult = $true
        break
    }

    if (-not $hasTerminalResult) {
        throw "所有可用 Worker Profile 均发生基础设施失败：$($attemptErrors -join '; ')"
    }
    exit $finalExitCode
}
catch {
    $message = $_.Exception.Message
    try { Publish-RawAttempts } catch {}
    if ($null -ne $run -and -not (Test-Path -LiteralPath $run.ErrorFile)) {
        try {
            Write-WorkerError `
                -Run $run `
                -Stage $failureStage `
                -ExitCode $workerExitCode `
                -Message $message `
                -StdErr $lastStdErr `
                -StdOut $lastStdOut
        }
        catch {
            [Console]::Error.WriteLine("Agent Worker 错误文件发布失败：$($_.Exception.Message)")
        }
    }
    [Console]::Error.WriteLine("Agent Worker 失败（$failureStage）：$message")
    exit 1
}
