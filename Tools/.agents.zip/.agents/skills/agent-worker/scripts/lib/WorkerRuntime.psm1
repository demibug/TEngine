Set-StrictMode -Version Latest

$script:Utf8NoBom = [System.Text.UTF8Encoding]::new($false)
$script:DefaultRetentionDays = 3
$script:RunIdPattern = '^[0-9a-f]{32}$'

function Get-WorkerCancellationEventName {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$RunId)

    if ($RunId -cnotmatch $script:RunIdPattern) { throw "RunId 格式无效：$RunId" }
    return "Local\Codex.AgentWorker.$RunId"
}

function New-WorkerCancellationContext {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$RunId)

    if ($null -eq ('AgentWorkerRuntime.AsyncWaitHandle' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AgentWorkerRuntime
{
    public static class AsyncWaitHandle
    {
        public static Task WaitAsync(WaitHandle waitHandle)
        {
            if (waitHandle == null) throw new ArgumentNullException(nameof(waitHandle));
            var source = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            RegisteredWaitHandle registration = null;
            registration = ThreadPool.RegisterWaitForSingleObject(
                waitHandle,
                (state, timedOut) =>
                {
                    ((TaskCompletionSource<bool>)state).TrySetResult(true);
                    registration?.Unregister(null);
                },
                source,
                Timeout.Infinite,
                true);
            return source.Task;
        }
    }
}
'@
    }

    $eventName = Get-WorkerCancellationEventName -RunId $RunId
    $createdNew = $false
    $waitHandle = [System.Threading.EventWaitHandle]::new(
        $false,
        [System.Threading.EventResetMode]::ManualReset,
        $eventName,
        [ref]$createdNew
    )
    if (-not $createdNew) {
        $waitHandle.Dispose()
        throw "Worker 取消事件已存在：$RunId"
    }
    return [PSCustomObject]@{
        EventName = $eventName
        WaitHandle = $waitHandle
        Task = [AgentWorkerRuntime.AsyncWaitHandle]::WaitAsync($waitHandle)
    }
}

function Resolve-WorkerProjectRoot {
    [CmdletBinding()]
    param()

    $fullPath = [System.IO.Path]::GetFullPath((Get-Location).Path)
    if (-not (Test-Path -LiteralPath $fullPath -PathType Container)) {
        throw "项目目录不存在：$fullPath"
    }
    return (Resolve-Path -LiteralPath $fullPath).Path
}

function ConvertTo-WorkerRelativePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ProjectDir,
        [Parameter(Mandatory = $true)][string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw 'WriteSet 不能包含空路径。'
    }
    if ([System.IO.Path]::IsPathRooted($Path)) {
        throw "WriteSet 必须使用工程相对路径：$Path"
    }
    if ($Path.IndexOfAny([char[]]'*?') -ge 0) {
        throw "WriteSet 只接受精确文件路径，不接受通配符：$Path"
    }

    $root = [System.IO.Path]::TrimEndingDirectorySeparator([System.IO.Path]::GetFullPath($ProjectDir))
    $fullPath = [System.IO.Path]::GetFullPath((Join-Path $root $Path))
    $rootPrefix = $root + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "WriteSet 路径越出工程目录：$Path"
    }

    # 防止工程内重解析点把预期路径映射到工程外。
    $cursor = [System.IO.Path]::GetDirectoryName($fullPath)
    while (
        -not [string]::IsNullOrWhiteSpace($cursor) -and
        $cursor.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)
    ) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "WriteSet 路径不能穿过重解析点：$Path"
            }
        }
        $cursor = [System.IO.Path]::GetDirectoryName($cursor)
    }

    return [System.IO.Path]::GetRelativePath($root, $fullPath).Replace('\', '/')
}

function Initialize-WorkerOutputRoot {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$ProjectDir)

    $outputRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectDir '.agent-worker-output'))
    [System.IO.Directory]::CreateDirectory($outputRoot) | Out-Null
    $rootInfo = Get-Item -LiteralPath $outputRoot -Force
    if (($rootInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Agent Worker 输出目录不能是重解析点：$outputRoot"
    }

    $runsRoot = Join-Path $rootInfo.FullName 'runs'
    [System.IO.Directory]::CreateDirectory($runsRoot) | Out-Null
    $runsInfo = Get-Item -LiteralPath $runsRoot -Force
    if (($runsInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Agent Worker runs 目录不能是重解析点：$runsRoot"
    }

    return [PSCustomObject]@{
        OutputRoot = $rootInfo.FullName
        RunsRoot = $runsInfo.FullName
        RetentionFile = Join-Path $rootInfo.FullName 'retention.json'
        LockFile = Join-Path $rootInfo.FullName '.cleanup.lock'
    }
}

function Write-WorkerAtomicText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [AllowEmptyString()][string]$Content = '',
        [switch]$ReplaceExisting
    )

    $partialPath = "$Path.partial"
    $stream = $null
    $writer = $null
    try {
        $stream = [System.IO.FileStream]::new(
            $partialPath,
            [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None
        )
        $writer = [System.IO.StreamWriter]::new($stream, $script:Utf8NoBom, 4096, $true)
        $writer.Write($Content)
        $writer.Flush()
        $stream.Flush($true)
        $writer.Dispose(); $writer = $null
        $stream.Dispose(); $stream = $null

        if (-not $ReplaceExisting -and [System.IO.File]::Exists($Path)) {
            throw "目标文件已存在，拒绝覆盖：$Path"
        }
        [System.IO.File]::Move($partialPath, $Path, [bool]$ReplaceExisting)
    }
    catch {
        if ([System.IO.File]::Exists($partialPath)) {
            [System.IO.File]::Delete($partialPath)
        }
        throw
    }
    finally {
        if ($null -ne $writer) { $writer.Dispose() }
        if ($null -ne $stream) { $stream.Dispose() }
    }
}

function Write-WorkerText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [AllowEmptyString()][string]$Content = ''
    )
    Write-WorkerAtomicText -Path $Path -Content $Content
}

function Write-WorkerJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][object]$Value,
        [switch]$ReplaceExisting
    )

    $json = (ConvertTo-Json -InputObject $Value -Depth 8) + [Environment]::NewLine
    Write-WorkerAtomicText -Path $Path -Content $json -ReplaceExisting:$ReplaceExisting
}

function New-WorkerRetentionState {
    return [ordered]@{
        version = 1
        retentionDays = $script:DefaultRetentionDays
        lastCleanupDate = ''
        lastDeletedCount = 0
    }
}

function Read-WorkerRetentionState {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return [PSCustomObject]@{ IsValid = $true; Exists = $false; Value = New-WorkerRetentionState }
    }
    try {
        $value = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if (
            [int]$value.version -ne 1 -or
            [int]$value.retentionDays -lt 1 -or
            $null -eq $value.lastCleanupDate -or
            $null -eq $value.lastDeletedCount
        ) {
            throw '字段缺失或值无效。'
        }
        if (
            -not [string]::IsNullOrWhiteSpace([string]$value.lastCleanupDate) -and
            [string]$value.lastCleanupDate -cnotmatch '^\d{4}-\d{2}-\d{2}$'
        ) {
            throw 'lastCleanupDate 格式无效。'
        }
        return [PSCustomObject]@{ IsValid = $true; Exists = $true; Value = $value }
    }
    catch {
        return [PSCustomObject]@{ IsValid = $false; Exists = $true; Value = New-WorkerRetentionState }
    }
}

function Write-WorkerLockContent {
    param(
        [Parameter(Mandatory = $true)][System.IO.FileStream]$Stream,
        [Parameter(Mandatory = $true)][object]$Value
    )

    $bytes = $script:Utf8NoBom.GetBytes((ConvertTo-Json -InputObject $Value -Compress))
    $Stream.Position = 0
    $Stream.SetLength(0)
    $Stream.Write($bytes, 0, $bytes.Length)
    $Stream.Flush($true)
}

function Enter-WorkerCleanupLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][datetime]$Today
    )

    $todayText = $Today.Date.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
    $lockValue = [ordered]@{ date = $todayText; processId = $PID }
    try {
        $stream = [System.IO.FileStream]::new(
            $Path,
            [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
        try { Write-WorkerLockContent -Stream $stream -Value $lockValue }
        finally { $stream.Dispose() }
        return [PSCustomObject]@{ Acquired = $true; Reason = 'Created'; Date = $todayText; ProcessId = $PID }
    }
    catch [System.IO.IOException] {
        $stream = $null
        try {
            $stream = [System.IO.FileStream]::new(
                $Path,
                [System.IO.FileMode]::Open,
                [System.IO.FileAccess]::ReadWrite,
                [System.IO.FileShare]::None
            )
            $reader = [System.IO.StreamReader]::new($stream, $script:Utf8NoBom, $true, 1024, $true)
            try { $text = $reader.ReadToEnd() }
            finally { $reader.Dispose() }
            try {
                $current = $text | ConvertFrom-Json -ErrorAction Stop
                $lockDate = [datetime]::ParseExact(
                    [string]$current.date,
                    'yyyy-MM-dd',
                    [System.Globalization.CultureInfo]::InvariantCulture
                ).Date
            }
            catch {
                Write-Warning "Agent Worker 清理锁损坏，本次跳过清理：$Path"
                return [PSCustomObject]@{ Acquired = $false; Reason = 'InvalidLock'; Date = $todayText; ProcessId = $PID }
            }

            if ($lockDate -ge $Today.Date) {
                return [PSCustomObject]@{ Acquired = $false; Reason = 'LockedToday'; Date = $todayText; ProcessId = $PID }
            }

            # 独占打开后原位替换昨日或更早的崩溃残留锁，避免并发删除窗口。
            Write-WorkerLockContent -Stream $stream -Value $lockValue
            return [PSCustomObject]@{ Acquired = $true; Reason = 'ReplacedStale'; Date = $todayText; ProcessId = $PID }
        }
        catch [System.IO.IOException] {
            return [PSCustomObject]@{ Acquired = $false; Reason = 'LockBusy'; Date = $todayText; ProcessId = $PID }
        }
        finally {
            if ($null -ne $stream) { $stream.Dispose() }
        }
    }
}

function Exit-WorkerCleanupLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Date,
        [Parameter(Mandatory = $true)][int]$ProcessId
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    try {
        $value = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if ([string]$value.date -eq $Date -and [int]$value.processId -eq $ProcessId) {
            [System.IO.File]::Delete($Path)
        }
    }
    catch {
        Write-Warning "Agent Worker 清理锁释放失败：$($_.Exception.Message)"
    }
}

function Test-WorkerRunDeletionTarget {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][System.IO.DirectoryInfo]$Directory,
        [Parameter(Mandatory = $true)][string]$RunsRoot,
        [Parameter(Mandatory = $true)][string]$ProjectDir,
        [Parameter(Mandatory = $true)][datetime]$DeleteBeforeDate
    )

    if ($Directory.Name -cnotmatch $script:RunIdPattern) { return $false }
    if (($Directory.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }

    $runsPrefix = [System.IO.Path]::TrimEndingDirectorySeparator([System.IO.Path]::GetFullPath($RunsRoot)) +
        [System.IO.Path]::DirectorySeparatorChar
    $fullDirectory = [System.IO.Path]::GetFullPath($Directory.FullName)
    if (-not $fullDirectory.StartsWith($runsPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }

    $metadataPath = Join-Path $fullDirectory 'metadata.json'
    try {
        $metadata = Get-Content -LiteralPath $metadataPath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if ([string]$metadata.runId -cne $Directory.Name) { return $false }
        $metadataWorkspace = [System.IO.Path]::TrimEndingDirectorySeparator(
            [System.IO.Path]::GetFullPath([string]$metadata.workspacePath)
        )
        $currentWorkspace = [System.IO.Path]::TrimEndingDirectorySeparator(
            [System.IO.Path]::GetFullPath($ProjectDir)
        )
        if (-not $metadataWorkspace.Equals($currentWorkspace, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $false
        }
        $createdDate = [datetime]::ParseExact(
            [string]$metadata.createdDate,
            'yyyy-MM-dd',
            [System.Globalization.CultureInfo]::InvariantCulture
        ).Date
        return $createdDate -lt $DeleteBeforeDate.Date
    }
    catch {
        Write-Warning "Agent Worker Run metadata 无效，已保留：$fullDirectory"
        return $false
    }
}

function Clear-WorkerDirectoryReadOnlyAttributes {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)

    # 先完整枚举再修改属性；若目录树中出现重解析点，绝不触碰它或其目标。
    $root = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    $items = [System.Collections.Generic.List[System.IO.FileSystemInfo]]::new()
    $items.Add($root)
    foreach ($item in @(Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction Stop)) {
        $items.Add($item)
    }
    foreach ($item in $items) {
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "拒绝删除包含重解析点的目录：$($item.FullName)"
        }
    }

    $cleared = [System.Collections.Generic.List[object]]::new()
    foreach ($item in $items) {
        $attributes = $item.Attributes
        if (($attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
            $cleared.Add([PSCustomObject]@{
                Path = $item.FullName
                Attributes = $attributes.ToString()
            })
            $item.Attributes = $attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)
        }
    }
    return $cleared.ToArray()
}

function Remove-WorkerDirectorySafely {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateRange(0, 5)][int]$MaxRetries = 5,
        # 仅供自测注入瞬时/持续删除失败；生产调用保持未设置。
        [scriptblock]$DeleteAction
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not (Test-Path -LiteralPath $fullPath -PathType Container)) {
        return [PSCustomObject]@{ Deleted = $false; Attempts = 0; Path = $fullPath }
    }

    $retryDelaysMilliseconds = @(100, 200, 400, 800, 1600)
    $lastError = $null
    $lastReadOnlyItem = $null
    for ($retry = 0; $retry -le $MaxRetries; $retry++) {
        $attempt = $retry + 1
        try {
            $clearedItems = @(Clear-WorkerDirectoryReadOnlyAttributes -Path $fullPath)
            if ($clearedItems.Count -gt 0) {
                $lastReadOnlyItem = $clearedItems[$clearedItems.Count - 1]
            }
            if ($null -eq $DeleteAction) {
                [System.IO.Directory]::Delete($fullPath, $true)
            }
            else {
                & $DeleteAction $fullPath
            }
            return [PSCustomObject]@{ Deleted = $true; Attempts = $attempt; Path = $fullPath }
        }
        catch [System.IO.IOException] {
            $lastError = $_
        }
        catch [System.UnauthorizedAccessException] {
            $lastError = $_
        }

        if ($retry -ge $MaxRetries) { break }
        Start-Sleep -Milliseconds $retryDelaysMilliseconds[$retry]
    }

    $failedItemPath = if ($null -ne $lastReadOnlyItem) { [string]$lastReadOnlyItem.Path } else { $fullPath }
    $failedItemAttributes = if ($null -ne $lastReadOnlyItem) { [string]$lastReadOnlyItem.Attributes } else {
        try { (Get-Item -LiteralPath $fullPath -Force -ErrorAction Stop).Attributes.ToString() } catch { '<unavailable>' }
    }
    $attemptCount = $MaxRetries + 1
    $details = @(
        'CleanupWarning:'
        "Path: $fullPath"
        "FailedItem: $failedItemPath"
        "Attributes: $failedItemAttributes"
        "Attempts: $attemptCount"
        "Error: $($lastError.Exception.Message)"
    ) -join [Environment]::NewLine
    throw [System.IO.IOException]::new($details, $lastError.Exception)
}

function Invoke-WorkerCleanup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ProjectDir,
        [datetime]$Today = [DateTime]::Today
    )

    $paths = Initialize-WorkerOutputRoot -ProjectDir $ProjectDir
    $todayText = $Today.Date.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
    $retention = Read-WorkerRetentionState -Path $paths.RetentionFile
    if (-not $retention.IsValid) {
        Write-Warning 'Agent Worker retention.json 损坏；已重建默认配置，本次不删除任何 Run。'
        Write-WorkerJson -Path $paths.RetentionFile -Value (New-WorkerRetentionState) -ReplaceExisting
        return [PSCustomObject]@{ DeletedCount = 0; Skipped = $true; Reason = 'InvalidConfig' }
    }
    if ([string]$retention.Value.lastCleanupDate -eq $todayText) {
        return [PSCustomObject]@{ DeletedCount = 0; Skipped = $true; Reason = 'AlreadyCleanedToday' }
    }

    $lock = Enter-WorkerCleanupLock -Path $paths.LockFile -Today $Today
    if (-not $lock.Acquired) {
        return [PSCustomObject]@{ DeletedCount = 0; Skipped = $true; Reason = $lock.Reason }
    }

    try {
        # 获锁后重新读取，避免另一个进程刚完成今日清理时重复枚举。
        $retention = Read-WorkerRetentionState -Path $paths.RetentionFile
        if (-not $retention.IsValid) {
            Write-Warning 'Agent Worker retention.json 在等待锁期间损坏，本次不删除任何 Run。'
            Write-WorkerJson -Path $paths.RetentionFile -Value (New-WorkerRetentionState) -ReplaceExisting
            return [PSCustomObject]@{ DeletedCount = 0; Skipped = $true; Reason = 'InvalidConfigAfterLock' }
        }
        if ([string]$retention.Value.lastCleanupDate -eq $todayText) {
            return [PSCustomObject]@{ DeletedCount = 0; Skipped = $true; Reason = 'AlreadyCleanedTodayAfterLock' }
        }

        $deleteBeforeDate = $Today.Date.AddDays(-[int]$retention.Value.retentionDays)
        $deletedCount = 0
        foreach ($directory in @(Get-ChildItem -LiteralPath $paths.RunsRoot -Directory -Force)) {
            if (Test-WorkerRunDeletionTarget `
                -Directory $directory `
                -RunsRoot $paths.RunsRoot `
                -ProjectDir $ProjectDir `
                -DeleteBeforeDate $deleteBeforeDate
            ) {
                try {
                    [void](Remove-WorkerDirectorySafely -Path $directory.FullName)
                    $deletedCount++
                }
                catch {
                    # 过期缓存删除失败不应中止整个清理批次；下次保留期清理会再次尝试。
                    Write-Warning $_.Exception.Message
                }
            }
        }

        $nextState = [ordered]@{
            version = 1
            retentionDays = [int]$retention.Value.retentionDays
            lastCleanupDate = $todayText
            lastDeletedCount = $deletedCount
        }
        Write-WorkerJson -Path $paths.RetentionFile -Value $nextState -ReplaceExisting
        return [PSCustomObject]@{ DeletedCount = $deletedCount; Skipped = $false; Reason = 'Completed' }
    }
    finally {
        Exit-WorkerCleanupLock -Path $paths.LockFile -Date $lock.Date -ProcessId $lock.ProcessId
    }
}

function New-WorkerRun {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ProjectDir,
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$RequestedBackend,
        [Parameter(Mandatory = $true)][string]$RequestedProfile,
        [datetime]$Today = [DateTime]::Today,
        [datetime]$NowUtc = [DateTime]::UtcNow
    )

    $paths = Initialize-WorkerOutputRoot -ProjectDir $ProjectDir
    $runId = [Guid]::NewGuid().ToString('N')
    $runDir = Join-Path $paths.RunsRoot $runId
    if ([System.IO.Directory]::Exists($runDir)) {
        throw "Agent Worker RunId 已存在：$runId"
    }
    [System.IO.Directory]::CreateDirectory($runDir) | Out-Null
    $runInfo = Get-Item -LiteralPath $runDir -Force
    if (($runInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Agent Worker 运行目录不能是重解析点：$runDir"
    }

    $metadataFile = Join-Path $runInfo.FullName 'metadata.json'
    $metadata = [ordered]@{
        version = 1
        runId = $runId
        createdDate = $Today.Date.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        createdAtUtc = $NowUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ', [System.Globalization.CultureInfo]::InvariantCulture)
        workspacePath = [System.IO.Path]::GetFullPath($ProjectDir)
        kind = $Kind
        requestedBackend = $RequestedBackend
        requestedProfile = $RequestedProfile
    }
    Write-WorkerJson -Path $metadataFile -Value $metadata

    return [PSCustomObject]@{
        RunId = $runId
        RunDir = $runInfo.FullName
        MetadataFile = $metadataFile
        ResultFile = Join-Path $runInfo.FullName 'result.txt'
        ErrorFile = Join-Path $runInfo.FullName 'error.txt'
        RawTextFile = Join-Path $runInfo.FullName 'raw.txt'
        RawNdjsonFile = Join-Path $runInfo.FullName 'raw.ndjson'
    }
}

function Write-WorkerResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][psobject]$Run,
        [Parameter(Mandatory = $true)][string]$Content
    )
    Write-WorkerText -Path $Run.ResultFile -Content $Content
}

function Write-WorkerError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][psobject]$Run,
        [Parameter(Mandatory = $true)][string]$Stage,
        [AllowNull()][Nullable[int]]$ExitCode,
        [Parameter(Mandatory = $true)][string]$Message,
        [AllowEmptyString()][string]$StdErr = '',
        [AllowEmptyString()][string]$StdOut = ''
    )

    $exitCodeText = if ($null -eq $ExitCode) { 'null' } else { [string]$ExitCode }
    $content = @(
        "FailureStage: $Stage"
        "ExitCode: $exitCodeText"
        ''
        'Message:'
        $Message
        ''
        'STDERR:'
        $(if ([string]::IsNullOrEmpty($StdErr)) { '<empty>' } else { $StdErr })
        ''
        'STDOUT:'
        $(if ([string]::IsNullOrEmpty($StdOut)) { '<empty>' } else { $StdOut })
    ) -join [Environment]::NewLine
    Write-WorkerText -Path $Run.ErrorFile -Content $content
}

function Start-WorkerProcess {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$ArgumentList,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory,
        [hashtable]$Environment = @{},
        [AllowEmptyString()][string]$InputText = '',
        [Parameter(Mandatory = $true)][ValidateRange(1, 3600)][int]$TimeoutSeconds,
        [System.Threading.Tasks.Task]$CancellationTask = $null
    )

    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $FilePath
    $startInfo.WorkingDirectory = $WorkingDirectory
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.StandardInputEncoding = $script:Utf8NoBom
    $startInfo.StandardOutputEncoding = $script:Utf8NoBom
    $startInfo.StandardErrorEncoding = $script:Utf8NoBom
    foreach ($argument in $ArgumentList) { $startInfo.ArgumentList.Add([string]$argument) }
    foreach ($entry in $Environment.GetEnumerator()) {
        $startInfo.Environment[[string]$entry.Key] = [string]$entry.Value
    }

    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) { throw "Worker 进程启动失败：$FilePath" }
        if (-not [string]::IsNullOrEmpty($InputText)) { $process.StandardInput.Write($InputText) }
        $process.StandardInput.Close()
        $stdout = [System.Text.StringBuilder]::new()
        $stderr = [System.Text.StringBuilder]::new()
        $stdoutDone = $false
        $stderrDone = $false
        $stdoutTask = $process.StandardOutput.ReadLineAsync()
        $stderrTask = $process.StandardError.ReadLineAsync()
        $timedOut = $false
        $cancelled = $false
        $permissionBlocked = $false
        $blockText = ''
        $terminationRequested = $false
        $terminationDeadlineMilliseconds = [long]::MaxValue
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

        # ReadLineAsync 完成时由任务调度器唤醒，不使用固定频率轮询三个 backend。
        while (-not ($stdoutDone -and $stderrDone)) {
            $waitTasks = [System.Collections.Generic.List[System.Threading.Tasks.Task]]::new()
            if (-not $stdoutDone) { $waitTasks.Add($stdoutTask) }
            if (-not $stderrDone) { $waitTasks.Add($stderrTask) }
            if (-not $terminationRequested -and $null -ne $CancellationTask) {
                $waitTasks.Add($CancellationTask)
            }

            $remainingMilliseconds = if ($terminationRequested) {
                $terminationDeadlineMilliseconds - $stopwatch.ElapsedMilliseconds
            }
            else {
                ([long]$TimeoutSeconds * 1000L) - $stopwatch.ElapsedMilliseconds
            }
            if ($remainingMilliseconds -le 0) {
                if ($terminationRequested) {
                    throw 'Worker 已请求终止，但输出流未在 30 秒内关闭。'
                }
                $timedOut = $true
                $terminationRequested = $true
                $terminationDeadlineMilliseconds = $stopwatch.ElapsedMilliseconds + 30000L
                try { $process.Kill($true) } catch {}
                continue
            }

            $waitMilliseconds = [int][Math]::Min($remainingMilliseconds, [int]::MaxValue)
            $waitIndex = [System.Threading.Tasks.Task]::WaitAny(
                [System.Threading.Tasks.Task[]]$waitTasks.ToArray(),
                $waitMilliseconds
            )
            if ($waitIndex -lt 0) {
                if ($terminationRequested) {
                    throw 'Worker 已请求终止，但输出流未在 30 秒内关闭。'
                }
                $timedOut = $true
                $terminationRequested = $true
                $terminationDeadlineMilliseconds = $stopwatch.ElapsedMilliseconds + 30000L
                try { $process.Kill($true) } catch {}
                continue
            }

            if (
                -not $terminationRequested -and
                $null -ne $CancellationTask -and
                $CancellationTask.IsCompleted
            ) {
                $cancelled = $true
                $terminationRequested = $true
                $terminationDeadlineMilliseconds = $stopwatch.ElapsedMilliseconds + 30000L
                try { $process.Kill($true) } catch {}
                continue
            }

            if (-not $stdoutDone -and $stdoutTask.IsCompleted) {
                $line = $stdoutTask.GetAwaiter().GetResult()
                if ($null -eq $line) {
                    $stdoutDone = $true
                }
                else {
                    [void]$stdout.AppendLine($line)
                    if (-not $terminationRequested -and (Test-WorkerPermissionBlockLine -Line $line)) {
                        $permissionBlocked = $true
                        $blockText = if ($line.Length -gt 1000) { $line.Substring(0, 1000) } else { $line }
                        $terminationRequested = $true
                        $terminationDeadlineMilliseconds = $stopwatch.ElapsedMilliseconds + 30000L
                        try { $process.Kill($true) } catch {}
                    }
                    $stdoutTask = $process.StandardOutput.ReadLineAsync()
                }
            }
            if (-not $stderrDone -and $stderrTask.IsCompleted) {
                $line = $stderrTask.GetAwaiter().GetResult()
                if ($null -eq $line) {
                    $stderrDone = $true
                }
                else {
                    [void]$stderr.AppendLine($line)
                    if (-not $terminationRequested -and (Test-WorkerPermissionBlockLine -Line $line)) {
                        $permissionBlocked = $true
                        $blockText = if ($line.Length -gt 1000) { $line.Substring(0, 1000) } else { $line }
                        $terminationRequested = $true
                        $terminationDeadlineMilliseconds = $stopwatch.ElapsedMilliseconds + 30000L
                        try { $process.Kill($true) } catch {}
                    }
                    $stderrTask = $process.StandardError.ReadLineAsync()
                }
            }
        }
        $stopwatch.Stop()
        if (-not $process.HasExited -and -not $process.WaitForExit(30000)) {
            throw 'Worker 已请求终止，但无法确认进程树已退出。'
        }
        return [PSCustomObject]@{
            ExitCode = $process.ExitCode
            StdOut = $stdout.ToString()
            StdErr = $stderr.ToString()
            TimedOut = $timedOut
            Cancelled = $cancelled
            PermissionBlocked = $permissionBlocked
            BlockText = $blockText
        }
    }
    finally {
        $process.Dispose()
    }
}

function Test-WorkerPermissionBlockLine {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Line)

    if ([string]::IsNullOrWhiteSpace($Line)) { return $false }
    try {
        $frame = $Line | ConvertFrom-Json -ErrorAction Stop
        $frameType = [string]$frame.type
        if ($frameType -eq 'assistant') { return $false }
        if ($frameType -eq 'result' -and [string]$frame.subtype -eq 'success') { return $false }
    }
    catch {
        # 非 JSON 行继续按 stderr、工具输出和系统事件处理。
    }
    $permissionBlockPattern = @'
(?ix)
(?:
    \b(?:EACCES|EPERM|UnauthorizedAccessException)\b
    | permission[ _-]?denied
    | operation[ _-]?not[ _-]?permitted
    | access[ ](?:to[ ].{1,300}?[ ])?is[ ]denied
    | access[ _-]?denied
    | you[ ](?:do[ ]not|don't)[ ]have[ ]permission[ ]to[ ](?:read|write|create|delete|modify|open)
    | (?:read|write|create|delete|modify|open)[^\r\n]{0,120}(?:blocked|denied)[^\r\n]{0,80}(?:sandbox|permission)
    | (?:sandbox|permission)[^\r\n]{0,120}(?:blocked|denied)[^\r\n]{0,80}(?:read|write|create|delete|modify|open)
    | outside[ ](?:the[ ])?(?:allowed|writable)[ ](?:path|root|directory|workspace)
    | approval[ ](?:was[ ])?(?:denied|rejected)[^\r\n]{0,80}(?:read|write|create|delete|modify|open)
    | 拒绝访问
    | 对路径.{1,300}?的访问被拒绝
    | 没有权限.{0,80}?(?:读取|写入|创建|删除|修改|打开)
    | (?:读取|写入|创建|删除|修改|打开).{0,80}?(?:被阻止|被拒绝|权限不足)
)
'@
    return $Line -match $permissionBlockPattern
}

function Test-WorkerBackendWideFailure {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Category)
    return $Category -in @('CliMissing', 'Config', 'Auth')
}

function Test-WorkerOutcome {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Content)

    $resultContent = $Content.Trim()
    if ([string]::IsNullOrWhiteSpace($resultContent)) { throw 'Worker 结果为空。' }
    $matches = [regex]::Matches(
        $resultContent,
        '(?im)^\s*WorkerOutcome:\s*(Completed|NeedsDecision|Failed)\s*$'
    )
    if ($matches.Count -ne 1) {
        throw 'Worker 结果必须包含且只能包含一个合法 WorkerOutcome 终态字段。'
    }

    $outcome = $matches[0].Groups[1].Value
    $resultContent = [regex]::Replace(
        $resultContent,
        '(?im)^\s*WorkerOutcome:\s*(Completed|NeedsDecision|Failed)\s*\r?\n?',
        ''
    ).Trim()
    if ([string]::IsNullOrWhiteSpace($resultContent)) { throw 'Worker 结果正文为空。' }
    if (
        $outcome -eq 'Completed' -and
        $resultContent -match '(?im)^\s*(?:权限[^\r\n]*(?:拒绝|失败)|(?:验证|自测)[^\r\n]*失败|任务[^\r\n]*(?:未完成|无法完成)|permission denied|validation failed|task (?:incomplete|failed))'
    ) {
        throw 'Worker 正文明确报告失败，不能标记为 Completed。'
    }
    return [PSCustomObject]@{ Outcome = $outcome; Content = $resultContent }
}

function Format-WorkerPathList {
    param([string[]]$Paths)
    if ($Paths.Count -eq 0) { return '<none>' }
    return ($Paths | ForEach-Object { "- $_" }) -join [Environment]::NewLine
}

function Add-WorkerMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Content,
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Backend,
        [Parameter(Mandatory = $true)][string]$Profile,
        [Parameter(Mandatory = $true)][ValidateSet('Completed', 'NeedsDecision', 'Failed', 'Cancelled')][string]$Outcome,
        [string[]]$ExpectedWriteSet = @(),
        [string[]]$ActualChangedFiles = @(),
        [string[]]$OutOfWriteSetChanges = @()
    )

    $lines = @($Content -split '\r?\n')
    $filtered = @($lines | Where-Object {
        $_ -notmatch '(?i)^\s*(WorkerOutcome|RunId|Kind|Backend|Profile):'
    })
    if ($filtered.Count -eq 0) { throw 'Worker 结果为空。' }
    $metadata = @(
        "WorkerOutcome: $Outcome"
        "RunId: $RunId"
        "Kind: $Kind"
        "Backend: $Backend"
        "Profile: $Profile"
        'ExpectedWriteSet:'
        (Format-WorkerPathList -Paths $ExpectedWriteSet)
        'ActualChangedFiles:'
        (Format-WorkerPathList -Paths $ActualChangedFiles)
        'OutOfWriteSetChanges:'
        (Format-WorkerPathList -Paths $OutOfWriteSetChanges)
    )
    return (@($filtered) + '' + $metadata) -join [Environment]::NewLine
}

function Get-WorkerWorkspaceSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$ProjectDir)

    $root = [System.IO.Path]::TrimEndingDirectorySeparator([System.IO.Path]::GetFullPath($ProjectDir))
    $excludedNames = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($name in @('.agent-worker-output', '.git', '.svn', 'Library', 'Temp', 'Logs', 'obj', '.vs')) {
        [void]$excludedNames.Add($name)
    }
    $snapshot = @{}
    $pending = [System.Collections.Generic.Stack[string]]::new()
    $pending.Push($root)
    while ($pending.Count -gt 0) {
        $directory = $pending.Pop()
        foreach ($childDirectory in [System.IO.Directory]::EnumerateDirectories($directory)) {
            $info = [System.IO.DirectoryInfo]::new($childDirectory)
            if ($excludedNames.Contains($info.Name)) { continue }
            if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
            $pending.Push($info.FullName)
        }
        foreach ($filePath in [System.IO.Directory]::EnumerateFiles($directory)) {
            $info = [System.IO.FileInfo]::new($filePath)
            if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
            $relativePath = [System.IO.Path]::GetRelativePath($root, $info.FullName).Replace('\', '/')
            $snapshot[$relativePath] = "$($info.Length):$($info.LastWriteTimeUtc.Ticks)"
        }
    }
    return $snapshot
}

function Compare-WorkerWorkspaceSnapshot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][hashtable]$Before,
        [Parameter(Mandatory = $true)][hashtable]$After
    )

    $paths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($path in $Before.Keys) { [void]$paths.Add([string]$path) }
    foreach ($path in $After.Keys) { [void]$paths.Add([string]$path) }
    $changes = [System.Collections.Generic.List[object]]::new()
    foreach ($path in @($paths | Sort-Object)) {
        $beforeExists = $Before.ContainsKey($path)
        $afterExists = $After.ContainsKey($path)
        if (-not $beforeExists) {
            $changes.Add([PSCustomObject]@{ Path = $path; Change = 'Added' })
        }
        elseif (-not $afterExists) {
            $changes.Add([PSCustomObject]@{ Path = $path; Change = 'Deleted' })
        }
        elseif ([string]$Before[$path] -ne [string]$After[$path]) {
            $changes.Add([PSCustomObject]@{ Path = $path; Change = 'Modified' })
        }
    }
    return $changes.ToArray()
}

Export-ModuleMember -Function @(
    'Resolve-WorkerProjectRoot',
    'ConvertTo-WorkerRelativePath',
    'Initialize-WorkerOutputRoot',
    'Write-WorkerAtomicText',
    'Write-WorkerText',
    'Write-WorkerJson',
    'Remove-WorkerDirectorySafely',
    'Invoke-WorkerCleanup',
    'New-WorkerRun',
    'Write-WorkerResult',
    'Write-WorkerError',
    'Get-WorkerCancellationEventName',
    'New-WorkerCancellationContext',
    'Start-WorkerProcess',
    'Test-WorkerBackendWideFailure',
    'Test-WorkerOutcome',
    'Add-WorkerMetadata',
    'Get-WorkerWorkspaceSnapshot',
    'Compare-WorkerWorkspaceSnapshot'
)
