[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

$skillDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$delegate = Join-Path $PSScriptRoot 'delegate.ps1'
$runtimeModule = Join-Path $PSScriptRoot 'lib\WorkerRuntime.psm1'
$openCodeModule = Join-Path $PSScriptRoot 'backends\OpenCode.psm1'
$commandCodeModule = Join-Path $PSScriptRoot 'backends\CommandCode.psm1'
$claudeCodeModule = Join-Path $PSScriptRoot 'backends\ClaudeCode.psm1'
$configFile = Join-Path $skillDir 'config\workers.psd1'
$config = Import-PowerShellDataFile -LiteralPath $configFile
$testBase = [System.IO.Path]::GetFullPath((Get-Location).Path)
$projectDir = [System.IO.Directory]::CreateDirectory(
    (Join-Path $testBase ('.agent-worker-selftest-' + [Guid]::NewGuid().ToString('N')))
).FullName
$junctionPath = ''
$junctionTarget = ''

Import-Module $runtimeModule -Force
Import-Module $openCodeModule -Force
Import-Module $commandCodeModule -Force
Import-Module $claudeCodeModule -Force

function Assert-WorkerTest {
    param(
        [Parameter(Mandatory = $true)][bool]$Condition,
        [Parameter(Mandatory = $true)][string]$Message
    )
    if (-not $Condition) { throw "SELFTEST FAILED: $Message" }
}

function Invoke-DelegateTest {
    param(
        [Parameter(Mandatory = $true)][string]$Kind,
        [Parameter(Mandatory = $true)][string]$Mode,
        [string[]]$WriteSet = @(),
        [string]$ReviewOfRunId = ''
    )

    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = Join-Path $PSHOME 'pwsh.exe'
    $startInfo.WorkingDirectory = $projectDir
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    foreach ($argument in @(
        '-NoLogo', '-NoProfile', '-NonInteractive', '-File', $delegate,
        '-Kind', $Kind,
        '-Task', 'deterministic selftest',
        '-TestMode', $Mode,
        '-TimeoutSeconds', '30'
    )) {
        $startInfo.ArgumentList.Add($argument)
    }
    if ($WriteSet.Count -gt 0) {
        $startInfo.ArgumentList.Add('-WriteSet')
        foreach ($path in $WriteSet) { $startInfo.ArgumentList.Add($path) }
    }
    if (-not [string]::IsNullOrWhiteSpace($ReviewOfRunId)) {
        $startInfo.ArgumentList.Add('-ReviewOfRunId')
        $startInfo.ArgumentList.Add($ReviewOfRunId)
    }

    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    try {
        [void]$process.Start()
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        $runMatch = [regex]::Match($stdout, '(?im)^RunDir:\s*(.+?)\s*$')
        return [PSCustomObject]@{
            ExitCode = $process.ExitCode
            StdOut = $stdout
            StdErr = $stderr
            RunDir = if ($runMatch.Success) { $runMatch.Groups[1].Value.Trim() } else { '' }
        }
    }
    finally {
        $process.Dispose()
    }
}

function New-FakeRun {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][datetime]$CreatedDate,
        [string]$RunId = ([Guid]::NewGuid().ToString('N')),
        [string]$WorkspacePath = '',
        [switch]$InvalidMetadata
    )

    if ([string]::IsNullOrWhiteSpace($WorkspacePath)) {
        $WorkspacePath = [System.IO.Directory]::GetParent([System.IO.Path]::GetFullPath($Root)).FullName
    }
    $runDir = [System.IO.Directory]::CreateDirectory((Join-Path $Root "runs\$RunId")).FullName
    $metadataPath = Join-Path $runDir 'metadata.json'
    if ($InvalidMetadata) {
        Write-WorkerText -Path $metadataPath -Content '{invalid'
    }
    else {
        Write-WorkerJson -Path $metadataPath -Value ([ordered]@{
            version = 1
            runId = $RunId
            createdDate = $CreatedDate.ToString('yyyy-MM-dd')
            createdAtUtc = $CreatedDate.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
            workspacePath = $WorkspacePath
            kind = 'Investigate'
            requestedBackend = 'ClaudeCode'
            requestedProfile = 'ClaudeCodeGLM'
        })
    }
    return $runDir
}

function Invoke-ConcurrentCleanup {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][datetime]$Today,
        [int]$Count = 3
    )

    $runtimeLiteral = $runtimeModule.Replace("'", "''")
    $rootLiteral = $Root.Replace("'", "''")
    $dateText = $Today.ToString('yyyy-MM-dd')
    $commandText = @"
`$WarningPreference = 'SilentlyContinue'
Import-Module '$runtimeLiteral' -Force
Invoke-WorkerCleanup -ProjectDir '$rootLiteral' -Today ([datetime]'$dateText') | ConvertTo-Json -Compress
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($commandText))
    $items = [System.Collections.Generic.List[object]]::new()
    for ($index = 0; $index -lt $Count; $index++) {
        $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = Join-Path $PSHOME 'pwsh.exe'
        $startInfo.WorkingDirectory = $Root
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        foreach ($argument in @('-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', $encoded)) {
            $startInfo.ArgumentList.Add($argument)
        }
        $process = [System.Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        [void]$process.Start()
        $items.Add([PSCustomObject]@{
            Process = $process
            StdOut = $process.StandardOutput.ReadToEndAsync()
            StdErr = $process.StandardError.ReadToEndAsync()
        })
    }

    $results = [System.Collections.Generic.List[object]]::new()
    foreach ($item in $items) {
        try {
            $item.Process.WaitForExit()
            $stdout = $item.StdOut.GetAwaiter().GetResult().Trim()
            $stderr = $item.StdErr.GetAwaiter().GetResult()
            Assert-WorkerTest ($item.Process.ExitCode -eq 0) "并发清理进程失败：$stderr"
            $results.Add(($stdout | ConvertFrom-Json -ErrorAction Stop))
        }
        finally {
            $item.Process.Dispose()
        }
    }
    return $results.ToArray()
}

try {
    # 配置、路由和 backend 最高权限参数保持确定。
    Assert-WorkerTest ($config.Profiles.ClaudeCodeGLM.Model -eq 'claude-glm-5.2') 'ClaudeCodeGLM 模型名不得改变。'
    Assert-WorkerTest ($config.Profiles.OpenCodeDeepSeek.Model -eq 'opencode-go/deepseek-v4-flash') 'OpenCode 模型名不得改变。'
    Assert-WorkerTest ($config.Profiles.CommandCodeDeepSeek.Model -eq 'deepseek/deepseek-v4-flash') 'CommandCode 模型名不得改变。'
    Assert-WorkerTest ($config.Profiles.ClaudeCodeGLM.Effort -eq 'high') 'ClaudeCodeGLM 推理强度必须为 high。'
    Assert-WorkerTest (-not $config.Profiles.OpenCodeDeepSeek.ContainsKey('Variant')) 'OpenCode 必须使用模型默认推理变体。'
    Assert-WorkerTest (-not $config.Profiles.CommandCodeDeepSeek.ContainsKey('Effort')) 'CommandCode 必须使用模型默认推理强度。'
    $expectedRoutes = @('ClaudeCodeGLM', 'OpenCodeDeepSeek', 'CommandCodeDeepSeek')
    Assert-WorkerTest `
        ((@($config.Routes) -join ',') -eq ($expectedRoutes -join ',')) `
        '通用路由顺序不得改变。'
    foreach ($kind in @('Explore', 'Investigate', 'Implement', 'InvestigateAndImplement', 'Review')) {
        $commandArgs = New-CommandCodeArguments -Kind $kind -Task 'selftest' -Model 'deepseek/deepseek-v4-flash'
        Assert-WorkerTest ($commandArgs -contains '--yolo') "$kind 必须使用 CommandCode --yolo。"
        Assert-WorkerTest ($commandArgs -contains '--tools-all') "$kind 必须使用 CommandCode --tools-all。"
        Assert-WorkerTest (-not ($commandArgs -contains '--plan')) "$kind 不得继续使用 CommandCode plan mode。"
        Assert-WorkerTest (-not ($commandArgs -contains '--effort')) "$kind 必须使用 CommandCode 默认推理强度。"

        $claudeArgs = New-ClaudeCodeArguments -Kind $kind -Model 'claude-glm-5.2' -Effort 'high'
        Assert-WorkerTest ($claudeArgs -contains '--dangerously-skip-permissions') "$kind 必须跳过 Claude 内层权限。"
        Assert-WorkerTest ($claudeArgs -contains '--safe-mode') "$kind 必须禁用 Claude 用户 hook 和插件。"
        Assert-WorkerTest (-not ($claudeArgs -contains '--permission-mode')) 'Claude 不得继续使用 auto permission mode。'
        Assert-WorkerTest (-not ($claudeArgs -contains '--settings')) 'Claude 不得注入临时 permissions/hooks settings。'
        Assert-WorkerTest ($claudeArgs -contains '--setting-sources') 'Claude 必须保留用户级 cc-switch settings。'
        Assert-WorkerTest ($claudeArgs -contains 'stream-json') 'Claude 必须实时输出事件流。'
        Assert-WorkerTest ($claudeArgs -contains '--verbose') 'Claude stream-json 必须启用 verbose。'
        Assert-WorkerTest (($claudeArgs[([array]::IndexOf($claudeArgs, '--effort') + 1)]) -eq 'high') "$kind 必须传递 Claude high effort。"
    }

    $permission = Get-OpenCodePermissionJson | ConvertFrom-Json
    foreach ($name in @('task', 'external_directory', 'edit', 'bash')) {
        Assert-WorkerTest ($permission.$name -eq 'allow') "OpenCode $name 必须为 allow。"
    }
    foreach ($removedKey in @('OpenCodeBashRules', 'CommandCodeAllowedCommands', 'ClaudeCodeBashAllowRules')) {
        Assert-WorkerTest (-not $config.ContainsKey($removedKey)) "workers.psd1 不得保留 $removedKey。"
    }
    Assert-WorkerTest (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'guards'))) 'guards 目录应在最终技能中删除。'

    $claudeSource = Get-Content -LiteralPath $claudeCodeModule -Raw -Encoding UTF8
    $commandSource = Get-Content -LiteralPath $commandCodeModule -Raw -Encoding UTF8
    foreach ($source in @($claudeSource, $commandSource)) {
        Assert-WorkerTest ($source -notmatch 'AGENT_WORKER_(ACTIVE|WRITESET|ALLOWED_COMMANDS)') 'backend 不得注入旧 guard 环境变量。'
    }

    $claudeStream = @(
        '{"type":"system","subtype":"init"}'
        '{"type":"assistant","message":{"content":[]}}'
        '{"type":"result","subtype":"success","is_error":false,"result":"验证完成。\nWorkerOutcome: Completed"}'
    ) -join [Environment]::NewLine
    $claudeResult = ConvertFrom-ClaudeCodeOutput -Content $claudeStream
    Assert-WorkerTest ($claudeResult -match '(?m)^WorkerOutcome: Completed\r?$') 'Claude 必须解析 stream-json 最终结果。'

    $assistantPermissionText = '{"type":"assistant","message":{"content":[{"type":"thinking","thinking":"验收确认 no EPERM，任务正常。"}]}}'
    $assistantBlocked = & (Get-Module WorkerRuntime) {
        param($line)
        Test-WorkerPermissionBlockLine -Line $line
    } $assistantPermissionText
    Assert-WorkerTest (-not $assistantBlocked) 'Claude assistant frame 中复述权限验收条件时不得误判为 BLOCK。'
    $systemPermissionText = '{"type":"system","subtype":"hook_response","output":"EPERM: operation not permitted"}'
    $systemBlocked = & (Get-Module WorkerRuntime) {
        param($line)
        Test-WorkerPermissionBlockLine -Line $line
    } $systemPermissionText
    Assert-WorkerTest $systemBlocked 'Claude system frame 中的真实 EPERM 必须立即判定为 BLOCK。'

    $completed = Test-WorkerOutcome -Content "完成。`nWorkerOutcome: Completed"
    Assert-WorkerTest ($completed.Outcome -eq 'Completed') '应解析 Completed 终态。'
    $decisionOutcome = Test-WorkerOutcome -Content "需要决策。`nWorkerOutcome: NeedsDecision"
    Assert-WorkerTest ($decisionOutcome.Outcome -eq 'NeedsDecision') '应解析 NeedsDecision 终态。'
    $failedOutcome = Test-WorkerOutcome -Content "验证失败。`nWorkerOutcome: Failed"
    Assert-WorkerTest ($failedOutcome.Outcome -eq 'Failed') '应解析 Failed 终态。'
    $missingOutcomeFailed = $false
    try { [void](Test-WorkerOutcome -Content '自然语言中提到失败，但没有终态字段。') }
    catch { $missingOutcomeFailed = $true }
    Assert-WorkerTest $missingOutcomeFailed '缺少 WorkerOutcome 必须失败。'

    # 输出目录、metadata、原子发布和终态退出码。
    $success = Invoke-DelegateTest -Kind Investigate -Mode Success
    Assert-WorkerTest ($success.ExitCode -eq 0) 'Completed 必须返回退出码 0。'
    Assert-WorkerTest ($success.RunDir -like "$projectDir\.agent-worker-output\runs\*") 'Run 必须写入新输出目录。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath (Join-Path $projectDir '.codex\agent-worker-output'))) 'delegate 不得写入旧 .codex 输出目录。'
    $successResult = Get-Content -LiteralPath (Join-Path $success.RunDir 'result.txt') -Raw -Encoding UTF8
    Assert-WorkerTest ($successResult -match '(?m)^WorkerOutcome: Completed\r?$') '结果必须发布机器终态。'
    Assert-WorkerTest ($successResult -match '(?m)^ExpectedWriteSet:\r?\n<none>') '结果必须包含 ExpectedWriteSet。'
    Assert-WorkerTest ($successResult -match '(?m)^ActualChangedFiles:\r?\n<none>') '结果必须包含 ActualChangedFiles。'
    Assert-WorkerTest ($successResult -match '(?m)^OutOfWriteSetChanges:\r?\n<none>') '结果必须包含 OutOfWriteSetChanges。'
    Assert-WorkerTest (Test-Path -LiteralPath (Join-Path $success.RunDir 'raw.txt') -PathType Leaf) 'raw.txt 应原子发布。'

    $metadata = Get-Content -LiteralPath (Join-Path $success.RunDir 'metadata.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    Assert-WorkerTest ([int]$metadata.version -eq 1) 'metadata version 应为 1。'
    Assert-WorkerTest ([string]$metadata.runId -eq [System.IO.Path]::GetFileName($success.RunDir)) 'metadata runId 应匹配目录名。'
    Assert-WorkerTest ([string]$metadata.workspacePath -eq $projectDir) 'metadata workspacePath 应匹配 workspace。'
    Assert-WorkerTest ([string]$metadata.kind -eq 'Investigate') 'metadata kind 应正确。'
    Assert-WorkerTest ([string]$metadata.requestedBackend -eq 'Test') 'metadata requestedBackend 应正确。'
    Assert-WorkerTest ([string]$metadata.requestedProfile -eq 'Test') 'metadata requestedProfile 应正确。'

    $reviewNew = Invoke-DelegateTest `
        -Kind Review `
        -Mode Success `
        -ReviewOfRunId ([System.IO.Path]::GetFileName($success.RunDir))
    Assert-WorkerTest ($reviewNew.ExitCode -eq 0) 'ReviewOfRunId 应优先读取新路径。'

    $legacyRunId = [Guid]::NewGuid().ToString('N')
    $legacyDir = [System.IO.Directory]::CreateDirectory(
        (Join-Path $projectDir ".codex\agent-worker-output\$legacyRunId")
    ).FullName
    $legacyResult = Add-WorkerMetadata `
        -Content '旧结果只读兼容。' `
        -RunId $legacyRunId `
        -Kind Investigate `
        -Backend Test `
        -Profile Test `
        -Outcome Completed
    Write-WorkerText -Path (Join-Path $legacyDir 'result.txt') -Content $legacyResult
    $reviewLegacy = Invoke-DelegateTest -Kind Review -Mode Success -ReviewOfRunId $legacyRunId
    Assert-WorkerTest ($reviewLegacy.ExitCode -eq 0) 'ReviewOfRunId 应只读兼容旧路径。'

    $decision = Invoke-DelegateTest `
        -Kind InvestigateAndImplement `
        -Mode NeedsDecision `
        -WriteSet @('expected.txt')
    Assert-WorkerTest ($decision.ExitCode -eq 2) 'NeedsDecision 必须返回独立退出码 2。'
    $decisionResult = Get-Content -LiteralPath (Join-Path $decision.RunDir 'result.txt') -Raw -Encoding UTF8
    Assert-WorkerTest ($decisionResult -match '(?m)^WorkerOutcome: NeedsDecision\r?$') 'NeedsDecision 应发布结果。'

    $semanticFailure = Invoke-DelegateTest `
        -Kind Implement `
        -Mode Failed `
        -WriteSet @('expected.txt')
    Assert-WorkerTest ($semanticFailure.ExitCode -eq 1) 'Failed 必须返回退出码 1。'
    $failureResult = Get-Content -LiteralPath (Join-Path $semanticFailure.RunDir 'result.txt') -Raw -Encoding UTF8
    Assert-WorkerTest ($failureResult -match '(?m)^WorkerOutcome: Failed\r?$') 'Failed 语义结果应发布 result.txt。'

    $empty = Invoke-DelegateTest -Kind Investigate -Mode EmptyResult
    Assert-WorkerTest ($empty.ExitCode -eq 1) '空结果必须失败。'
    Assert-WorkerTest (Test-Path -LiteralPath (Join-Path $empty.RunDir 'error.txt') -PathType Leaf) '空结果应原子发布 error.txt。'

    $outOfWriteSet = Invoke-DelegateTest `
        -Kind Implement `
        -Mode OutOfWriteSet `
        -WriteSet @('expected.txt')
    Assert-WorkerTest ($outOfWriteSet.ExitCode -eq 0) 'WriteSet 外修改允许完成。'
    $outsideResult = Get-Content -LiteralPath (Join-Path $outOfWriteSet.RunDir 'result.txt') -Raw -Encoding UTF8
    Assert-WorkerTest ($outsideResult -match '(?ms)^OutOfWriteSetChanges:\r?\n- \.agent-worker-selftest-outside-[0-9a-f]{32}\.txt') 'WriteSet 外修改必须报告。'
    $outsideMatch = [regex]::Match($outsideResult, '(?m)^- (\.agent-worker-selftest-outside-[0-9a-f]{32}\.txt)\r?$')
    Assert-WorkerTest $outsideMatch.Success '应能提取 WriteSet 外测试文件。'
    [System.IO.File]::Delete((Join-Path $projectDir $outsideMatch.Groups[1].Value))

    $timeout = Invoke-DelegateTest -Kind Investigate -Mode Timeout
    Assert-WorkerTest ($timeout.ExitCode -eq 1) 'Timeout 必须失败。'
    $timeoutRaw = Get-Content -LiteralPath (Join-Path $timeout.RunDir 'raw.txt') -Raw -Encoding UTF8
    $childMatch = [regex]::Match($timeoutRaw, 'TEST_CHILD_PID:(\d+)')
    Assert-WorkerTest $childMatch.Success 'Timeout 应记录子进程 PID。'
    Assert-WorkerTest `
        ($null -eq (Get-Process -Id ([int]$childMatch.Groups[1].Value) -ErrorAction SilentlyContinue)) `
        'Timeout 必须终止完整进程树。'

    foreach ($permissionMode in @('PermissionBlockStdOut', 'PermissionBlockStdErr')) {
        $blockWatch = [System.Diagnostics.Stopwatch]::StartNew()
        $permissionBlock = Invoke-DelegateTest -Kind Investigate -Mode $permissionMode
        $blockWatch.Stop()
        Assert-WorkerTest ($permissionBlock.ExitCode -eq 1) "$permissionMode 必须返回失败。"
        Assert-WorkerTest ($blockWatch.Elapsed.TotalSeconds -lt 10) "$permissionMode 必须立即返回，不得等待 timeout。"
        $blockRaw = Get-Content -LiteralPath (Join-Path $permissionBlock.RunDir 'raw.txt') -Raw -Encoding UTF8
        Assert-WorkerTest ($blockRaw -match '(?i)permission denied|access to the path') "$permissionMode 应保留 raw 证据。"
        $blockChildMatch = [regex]::Match($blockRaw, "TEST_PERMISSION_(?:STDOUT|STDERR)_CHILD_PID:(\d+)")
        Assert-WorkerTest $blockChildMatch.Success "$permissionMode 自测应记录子进程 PID。"
        Assert-WorkerTest `
            ($null -eq (Get-Process -Id ([int]$blockChildMatch.Groups[1].Value) -ErrorAction SilentlyContinue)) `
            "$permissionMode 必须终止完整进程树。"
    }

    $modelWarningWatch = [System.Diagnostics.Stopwatch]::StartNew()
    $modelWarning = Invoke-DelegateTest -Kind Investigate -Mode IgnoredModelWarning
    $modelWarningWatch.Stop()
    Assert-WorkerTest ($modelWarning.ExitCode -eq 0) 'unrecognized_model 告警后正常结果必须成功。'
    Assert-WorkerTest ($modelWarningWatch.Elapsed.TotalSeconds -ge 1.5) 'unrecognized_model 不得提前终止 worker。'
    $modelWarningRaw = Get-Content -LiteralPath (Join-Path $modelWarning.RunDir 'raw.txt') -Raw -Encoding UTF8
    Assert-WorkerTest ($modelWarningRaw -match 'unrecognized_model') '模型告警应保留 raw 诊断。'

    $partialFiles = @(Get-ChildItem -LiteralPath (Join-Path $projectDir '.agent-worker-output') -Recurse -Force -Filter '*.partial')
    Assert-WorkerTest ($partialFiles.Count -eq 0) 'result/error/raw/metadata 不得残留 partial。'

    # 固定日期验证自然日保留、合法删除目标和每日一次短路。
    $today = [datetime]'2026-08-18'
    $cleanupProject = [System.IO.Directory]::CreateDirectory((Join-Path $projectDir 'cleanup-calendar')).FullName
    $cleanupPaths = Initialize-WorkerOutputRoot -ProjectDir $cleanupProject
    $day0 = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today
    $day1 = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-1)
    $day2 = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-2)
    $day3 = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-3)
    $day4 = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-4)
    $nonRunDir = [System.IO.Directory]::CreateDirectory((Join-Path $cleanupPaths.RunsRoot 'keep-me')).FullName
    $invalidRun = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-10) -InvalidMetadata
    $wrongWorkspaceRun = New-FakeRun `
        -Root $cleanupPaths.OutputRoot `
        -CreatedDate $today.AddDays(-10) `
        -WorkspacePath (Join-Path $projectDir 'other-workspace')

    $junctionRunId = [Guid]::NewGuid().ToString('N')
    $junctionTarget = [System.IO.Directory]::CreateDirectory((Join-Path $cleanupProject 'junction-target')).FullName
    Write-WorkerJson -Path (Join-Path $junctionTarget 'metadata.json') -Value ([ordered]@{
        version = 1
        runId = $junctionRunId
        createdDate = $today.AddDays(-10).ToString('yyyy-MM-dd')
        createdAtUtc = '2026-08-08T00:00:00Z'
        workspacePath = $cleanupProject
        kind = 'Investigate'
        requestedBackend = 'ClaudeCode'
        requestedProfile = 'ClaudeCodeGLM'
    })
    $junctionPath = Join-Path $cleanupPaths.RunsRoot $junctionRunId
    [void](New-Item -ItemType Junction -Path $junctionPath -Target $junctionTarget)

    $calendarCleanup = Invoke-WorkerCleanup -ProjectDir $cleanupProject -Today $today
    Assert-WorkerTest (-not $calendarCleanup.Skipped) '当天首次运行必须执行清理。'
    Assert-WorkerTest ([int]$calendarCleanup.DeletedCount -eq 1) "仅 4 天前 Run 应被删除，实际删除 $($calendarCleanup.DeletedCount)。"
    foreach ($retained in @($day0, $day1, $day2, $day3, $nonRunDir, $invalidRun, $wrongWorkspaceRun, $junctionPath)) {
        Assert-WorkerTest (Test-Path -LiteralPath $retained) "应保留：$retained"
    }
    Assert-WorkerTest (-not (Test-Path -LiteralPath $day4)) '4 天前 Run 应删除。'
    $calendarState = Get-Content -LiteralPath $cleanupPaths.RetentionFile -Raw -Encoding UTF8 | ConvertFrom-Json
    Assert-WorkerTest ([string]$calendarState.lastCleanupDate -eq '2026-08-18') '清理状态应记录自然日。'
    Assert-WorkerTest ([int]$calendarState.lastDeletedCount -eq 1) '清理状态应记录删除数量。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $cleanupPaths.LockFile)) '清理完成后应释放锁。'

    $lateOldRun = New-FakeRun -Root $cleanupPaths.OutputRoot -CreatedDate $today.AddDays(-20)
    $sameDayCleanup = Invoke-WorkerCleanup -ProjectDir $cleanupProject -Today $today
    Assert-WorkerTest ($sameDayCleanup.Skipped -and $sameDayCleanup.Reason -eq 'AlreadyCleanedToday') '当天后续运行应立即短路。'
    Assert-WorkerTest (Test-Path -LiteralPath $lateOldRun) '当天短路不得枚举或删除后加 Run。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $cleanupPaths.LockFile)) '当天短路不得创建锁。'

    $nextDayCleanup = Invoke-WorkerCleanup -ProjectDir $cleanupProject -Today $today.AddDays(1)
    Assert-WorkerTest (-not $nextDayCleanup.Skipped) '进入第二天应再次执行一次清理。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $day3)) '第二天应按新的自然日阈值删除旧 Run。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $lateOldRun)) '第二天应删除后加的过期 Run。'

    # 配置损坏时重建但不删除，下次再清理。
    $corruptProject = [System.IO.Directory]::CreateDirectory((Join-Path $projectDir 'cleanup-corrupt')).FullName
    $corruptPaths = Initialize-WorkerOutputRoot -ProjectDir $corruptProject
    $corruptOldRun = New-FakeRun -Root $corruptPaths.OutputRoot -CreatedDate $today.AddDays(-20)
    Write-WorkerAtomicText -Path $corruptPaths.RetentionFile -Content '{broken' -ReplaceExisting
    $corruptCleanup = Invoke-WorkerCleanup -ProjectDir $corruptProject -Today $today -WarningAction SilentlyContinue
    Assert-WorkerTest ($corruptCleanup.Reason -eq 'InvalidConfig') '损坏配置应跳过删除。'
    Assert-WorkerTest (Test-Path -LiteralPath $corruptOldRun) '配置损坏时不得删除 Run。'
    $rebuiltState = Get-Content -LiteralPath $corruptPaths.RetentionFile -Raw -Encoding UTF8 | ConvertFrom-Json
    Assert-WorkerTest ([string]$rebuiltState.lastCleanupDate -eq '') '重建配置应让下次运行执行清理。'
    $corruptRetry = Invoke-WorkerCleanup -ProjectDir $corruptProject -Today $today
    Assert-WorkerTest (-not $corruptRetry.Skipped) '配置重建后的下次运行应清理。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $corruptOldRun)) '重试应删除过期 Run。'

    # 昨日崩溃残留锁可安全恢复。
    $staleProject = [System.IO.Directory]::CreateDirectory((Join-Path $projectDir 'cleanup-stale-lock')).FullName
    $stalePaths = Initialize-WorkerOutputRoot -ProjectDir $staleProject
    Write-WorkerJson -Path $stalePaths.LockFile -Value ([ordered]@{ date = '2026-08-17'; processId = 999999 })
    $staleCleanup = Invoke-WorkerCleanup -ProjectDir $staleProject -Today $today
    Assert-WorkerTest (-not $staleCleanup.Skipped) '昨日残留锁应恢复并完成清理。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $stalePaths.LockFile)) '恢复后应释放锁。'

    # 三进程并发时只有一个进程执行当天清理。
    $concurrentProject = [System.IO.Directory]::CreateDirectory((Join-Path $projectDir 'cleanup-concurrent')).FullName
    $concurrentPaths = Initialize-WorkerOutputRoot -ProjectDir $concurrentProject
    $concurrentOldRun = New-FakeRun -Root $concurrentPaths.OutputRoot -CreatedDate $today.AddDays(-20)
    $concurrentResults = @(Invoke-ConcurrentCleanup -Root $concurrentProject -Today $today -Count 3)
    Assert-WorkerTest (@($concurrentResults | Where-Object { -not $_.Skipped }).Count -eq 1) '并发清理只能有一个执行者。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $concurrentOldRun)) '并发清理应删除一次过期 Run。'
    Assert-WorkerTest (-not (Test-Path -LiteralPath $concurrentPaths.LockFile)) '并发清理后不得残留锁。'

    'Agent Worker selftest: PASS'
}
finally {
    # 先删除 junction 本身，避免递归清理跟随目标。
    if (-not [string]::IsNullOrWhiteSpace($junctionPath) -and (Test-Path -LiteralPath $junctionPath)) {
        [System.IO.Directory]::Delete($junctionPath, $false)
    }
    if (-not [string]::IsNullOrWhiteSpace($junctionTarget) -and (Test-Path -LiteralPath $junctionTarget)) {
        [System.IO.Directory]::Delete($junctionTarget, $true)
    }

    $fullProjectDir = [System.IO.Path]::GetFullPath($projectDir)
    $expectedPrefix = [System.IO.Path]::TrimEndingDirectorySeparator($testBase) +
        [System.IO.Path]::DirectorySeparatorChar + '.agent-worker-selftest-'
    if (
        $fullProjectDir.StartsWith($expectedPrefix, [System.StringComparison]::OrdinalIgnoreCase) -and
        [System.IO.Path]::GetFileName($fullProjectDir) -cmatch '^\.agent-worker-selftest-[0-9a-f]{32}$' -and
        (Test-Path -LiteralPath $fullProjectDir -PathType Container)
    ) {
        $info = Get-Item -LiteralPath $fullProjectDir -Force
        if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0) {
            [System.IO.Directory]::Delete($fullProjectDir, $true)
        }
    }
}
