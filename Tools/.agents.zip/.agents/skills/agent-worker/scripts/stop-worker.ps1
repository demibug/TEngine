[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Workspace,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-f]{32}$')]
    [string]$RunId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$runtimeModule = Join-Path $PSScriptRoot 'lib\WorkerRuntime.psm1'
Import-Module $runtimeModule -Force

$workspacePath = [System.IO.Path]::GetFullPath($Workspace)
if (-not (Test-Path -LiteralPath $workspacePath -PathType Container)) {
    throw "Workspace 不存在：$workspacePath"
}

$runDir = Join-Path $workspacePath ".agent-worker-output\runs\$RunId"
$runInfo = Get-Item -LiteralPath $runDir -Force -ErrorAction Stop
if (-not $runInfo.PSIsContainer) { throw "RunId 目录无效：$runDir" }
if (($runInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
    throw "RunId 目录不能是重解析点：$runDir"
}

$metadata = Get-Content -LiteralPath (Join-Path $runInfo.FullName 'metadata.json') -Raw -Encoding UTF8 |
    ConvertFrom-Json -ErrorAction Stop
$metadataWorkspace = [System.IO.Path]::TrimEndingDirectorySeparator(
    [System.IO.Path]::GetFullPath([string]$metadata.workspacePath)
)
$expectedWorkspace = [System.IO.Path]::TrimEndingDirectorySeparator($workspacePath)
if (
    [string]$metadata.runId -cne $RunId -or
    -not $metadataWorkspace.Equals($expectedWorkspace, [System.StringComparison]::OrdinalIgnoreCase)
) {
    throw "RunId metadata 与 Workspace 不匹配：$RunId"
}

$eventName = Get-WorkerCancellationEventName -RunId $RunId
$waitHandle = $null
try {
    try {
        $waitHandle = [System.Threading.EventWaitHandle]::OpenExisting($eventName)
    }
    catch [System.Threading.WaitHandleCannotBeOpenedException] {
        throw "Worker 未运行或已经结束：$RunId"
    }
    if (-not $waitHandle.Set()) { throw "Worker 取消信号发送失败：$RunId" }
    Write-Output "CancellationRequested: $RunId"
}
finally {
    if ($null -ne $waitHandle) { $waitHandle.Dispose() }
}
