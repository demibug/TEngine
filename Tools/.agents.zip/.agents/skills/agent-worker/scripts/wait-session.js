(async ({ cmd, workdir, sandbox_permissions, justification }) => {
  const options = {
    cmd,
    shell: "powershell",
    login: false,
    workdir,
    yield_time_ms: 10000,
    max_output_tokens: 3000
  };
  if (sandbox_permissions) options.sandbox_permissions = sandbox_permissions;
  if (justification) options.justification = justification;

  let result = await tools.exec_command(options);
  let output = result.output ?? "";
  let notifiedAt = Date.now();
  let runNotified = false;
  const notifyRun = chunk => {
    if (runNotified || !result.session_id || !chunk) return;
    const match = chunk.match(/(?:^|\r?\n)RunId:\s*([0-9a-f]{32})(?:\r?\n|$)/);
    if (!match) return;
    const workspace = workdir.replace(/'/g, "''");
    notify(`agent-worker RunId: ${match[1]}\n外部停止：& "$HOME\\.agents\\skills\\agent-worker\\scripts\\stop-worker.ps1" -Workspace '${workspace}' -RunId '${match[1]}'`);
    runNotified = true;
  };
  notifyRun(output);
  while (result.session_id) {
    result = await tools.write_stdin({
      session_id: result.session_id,
      chars: "",
      yield_time_ms: 30000,
      max_output_tokens: 3000
    });
    if (result.output) output = (output + result.output).slice(-12000);
    notifyRun(result.output);
    if (Date.now() - notifiedAt >= 55000) {
      notify("agent-worker 仍在执行，正在等待最终结果……");
      notifiedAt = Date.now();
    }
  }
  text(JSON.stringify({ exit_code: result.exit_code, output }));
})
