---
name: task-slice
description: 编排已确认包含多个独立交付目标、依赖、写入或共享契约冲突的代码任务，也用于用户明确要求拆分或并行时。单个有界目标使用 agent-worker；边界未知本身不触发切片。
---

# Task Slice

`task-slice` 是 `agent-worker` 之上的薄编排层，只管理任务图、ownership、契约冲突、执行波次和重规划；调查、实现、审查及技术决策仍由 Codex 和 `agent-worker` 负责。

## 建图

1. 仅在已有事实足以确定交付目标、依赖、共享契约、写入边界和验收时切片；否则按 `agent-worker` 的 Scout 规则补齐必要事实。
2. 调查后只有一个有界目标时，折叠为单个 `agent-worker` 任务。
3. 按可独立交付、可独立验收的目标切分，不按文件机械切分；用 `DependsOn` 构建 DAG，再由依赖和冲突派生 Wave。

每张任务卡只保留适用字段：

- `TaskId`、`Scope`、`Acceptance`
- `Produces`；必要时记录 `Consumes`
- 写任务的精确 `WriteSet`；只读任务不传
- `ContractReadSet`、`ContractWriteSet`
- `DependsOn`；`Wave` 仅作派生展示

不传 backend/profile，也不覆盖 `agent-worker` 的 Kind、Decision Risk、Decision Boundary 或结果协议。

## 调度约束

- `DependsOn` 是依赖的唯一事实来源；依赖、写集或契约变化后重新计算受影响 Wave。
- 并行写任务必须同时满足：依赖已完成、`WriteSet` 不重叠、契约不冲突、无其他共享状态写冲突。
- 契约冲突规则：Read/Read 可并行；Read/Write 与 Write/Write 不可并行。多个任务依赖未稳定契约时，先拆出唯一 owner 的上游契约任务。
- 每个写入范围只能归一个并行 slice。若 worker 发现必须扩大 `WriteSet`，停止范围外写入并返回所需路径、原因和影响，由 Codex 重分 ownership。
- 失败只阻止依赖该任务或其假设的子图；不受影响的任务可继续。

## 重规划与裁决

新事实推翻边界或依赖、需要扩大写集、共享契约变化、失败证明任务图前提错误，或必须新增集成任务时，标记 `NeedsReslice`。优先重算受影响子图，保留仍有效的事实和交付物；仅全局假设失效时重建全图。

Worker 结论矛盾时，以源码、测试或运行结果裁决；证据不足则发起针对性的 `Investigate`，不投票。架构、产品及其他 Decision Boundary 返回 Codex 或用户。

## 验收

先按任务卡和 `agent-worker` 协议逐项验收，再确认：

- `Produces` 已实际产生，实际改动符合最终 ownership；
- 消费者使用的共享契约与最终定义一致；
- ownership、依赖和契约冲突均已处理；
- 共同组成用户可见行为或端到端路径的多个写任务已通过图级集成验证。

所有必需 slice、依赖和集成验证均通过后，任务才完成。
