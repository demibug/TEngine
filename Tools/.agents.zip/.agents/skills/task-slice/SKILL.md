---
name: task-slice
description: 编排已确认包含多个独立交付目标、依赖波次或写冲突的复杂代码任务，也用于用户明确要求拆分或并行时。仅边界未知或存在多个可能方向不足以触发；单个有界目标使用 agent-worker。
---

# Task Slice

## 原则

只负责任务图、依赖、写冲突和执行波次；所有调查、实现和独立审查交给 `agent-worker`。不选择 backend、模型或结果协议。

## 流程

1. 检查可信上下文能否确定任务边界、依赖、共享契约、写区和验收；足够时直接构建 `TaskId`、Wave、`WriteSet` ownership 和 `DependsOn`。
2. 仅当未知项会阻止切片或验收时，调用聚焦的 `agent-worker / Explore` 或 `Investigate`，并在 `KnownContext` 传入已确认事实、缺口和前次 `RunId`。
3. 若只有一个有界任务，折叠为普通 `agent-worker` 调用。边界清楚时优先 `InvestigateAndImplement`；仅缺事实用 `Investigate`；已有完整决策用 `Implement`。Decision Boundary / `NeedsDecision` 返回 Codex 或用户。

## 切片与执行

- 按独立目标和契约切分，不按文件机械切分。
- 写任务必须有精确且唯一的预期 `WriteSet` ownership。不同 slice 的预期写集不得重叠，同文件、共享契约或不确定冲突不得并行；范围外变化由 Codex 检查实际冲突。
- 只读任务可并行；写任务仅在写集互斥且无共享契约时并行。
- 依赖另一 slice 的结论或接口时设置 `DependsOn`；失败只阻止依赖项。
- 矛盾结论用关键源码或针对性 `Investigate` 裁决，不投票。

任务卡沿用 `agent-worker` 契约，并按需增加 `TaskId`、`DependsOn` 和 Wave；只保留适用字段，不传 backend/profile。

## 验收

按 `agent-worker` 规则验收压缩结论；仅对 Decision Boundary、失败、冲突和高风险执行 Codex 技术判断。
